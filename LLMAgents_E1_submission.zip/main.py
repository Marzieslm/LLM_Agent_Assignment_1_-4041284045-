"""Entry point: ``python main.py --input input.json --output output.json``.

The program is deliberately dependency-free (standard library only) and performs all
model inference through a local Ollama server, so it runs offline once the model has
been pulled.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Any, Dict, List, Optional, Tuple

# Windows consoles default to a legacy code page; answers may contain Persian text.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # pragma: no cover - non-reconfigurable streams
        pass

from agent.config import DEFAULT_MODEL, build_config
from agent.ollama_client import OllamaClient, OllamaError
from agent.pipeline import Agent
from agent.trace import RunLog


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Local reasoning agent (Ollama) for the LLM-Agents exercise.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--input", help='input JSON file: {"id":..., "problem":...} or a list of them')
    p.add_argument("--output", help="output JSON file to write")
    p.add_argument("--problem", help="ad-hoc problem text (prints the answer instead of writing a file)")
    p.add_argument("--model", default=None, help="Ollama model name (default: $OLLAMA_MODEL or qwen3.8:27b)")
    p.add_argument("--host", default=None, help="Ollama host (default: $OLLAMA_HOST or http://127.0.0.1:11434)")
    p.add_argument("--profile", default=None, choices=["fast", "balanced", "max"], help="sampling budget profile")
    p.add_argument("--samples", type=int, default=None, help="number of CoT samples in fallback mode")
    p.add_argument("--max-samples", type=int, default=None)
    p.add_argument("--temperature", type=float, default=None)
    p.add_argument("--top-k", type=int, default=None, help="top_k sampling (0 = send nothing)")
    p.add_argument("--num-ctx", type=int, default=None, help="context window")
    p.add_argument("--think", default=None, choices=["auto", "on", "off"], help="thinking mode for hybrid models")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--call-timeout", type=float, default=None)
    p.add_argument("--problem-timeout", type=float, default=None)
    p.add_argument("--no-pot", action="store_true", help="disable program-of-thought")
    p.add_argument("--no-cache", action="store_true", help="disable the local LLM response cache")
    p.add_argument("--config", default=None, help="optional JSON config file")
    p.add_argument("--log-dir", default=None)
    p.add_argument("--log-file", default=None)
    p.add_argument("--verbose", action="store_true")
    p.add_argument("--list-models", action="store_true")
    return p.parse_args(argv)


def load_input(path: str) -> Tuple[List[Dict[str, Any]], bool]:
    """Return (items, was_single)."""
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    if isinstance(data, dict):
        if "problems" in data and isinstance(data["problems"], list):
            return [dict(x) for x in data["problems"]], False
        return [dict(data)], True
    if isinstance(data, list):
        return [dict(x) for x in data], False
    raise ValueError("input must be a JSON object or a list of objects")


def write_output(path: str, payload: Any) -> None:
    directory = os.path.dirname(os.path.abspath(path))
    if directory:
        os.makedirs(directory, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)


def pick_fallback_model(host: str, wanted: str) -> Optional[str]:
    """If the requested model is missing, choose the closest installed one (never silently)."""
    from difflib import SequenceMatcher

    try:
        client = OllamaClient(model=wanted, host=host)
        models = client.list_models()
    except Exception:
        return None
    if not models:
        return None
    lowered = {m: m.lower() for m in models}
    family = wanted.split(":")[0].lower()

    def score(name: str) -> float:
        return SequenceMatcher(None, wanted.lower(), lowered[name]).ratio()

    # 1) closest same-family name (so 27b is preferred over 2b when 27b was asked for)
    same = [m for m in models if lowered[m].startswith(family)]
    if same:
        return max(same, key=lambda m: (score(m), len(m)))
    # 2) any qwen family model
    qwen = [m for m in models if "qwen" in lowered[m]]
    if qwen:
        return max(qwen, key=lambda m: (score(m), len(m)))
    # 3) only installed model
    if len(models) == 1:
        return models[0]
    return None


def resolve_model(cfg, explicit: bool, verbose: bool) -> None:
    """Verify the model is installed; fall back to a same-family model if not.

    The grader may use a tag that differs slightly from the local one.  Scoring zero
    because of a tag mismatch is worse than running a clearly reported substitute, so
    we fall back with a loud warning (``--strict-model`` disables this).
    """
    client = OllamaClient(model=cfg.model, host=cfg.host)
    try:
        client.ensure_available()
        return
    except OllamaError as exc:
        fallback = pick_fallback_model(cfg.host, cfg.model)
        if not fallback:
            raise OllamaError(str(exc)) from exc
        print(
            f"[warn] model '{cfg.model}' is not installed; using '{fallback}' instead.\n"
            f"       Pull the official model with: ollama pull {cfg.model}",
            file=sys.stderr,
        )
        cfg.model = fallback


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)

    # --list-models
    if args.list_models:
        host = args.host or os.environ.get("OLLAMA_HOST") or "http://127.0.0.1:11434"
        if not host.startswith("http"):
            host = "http://" + host
        try:
            models = OllamaClient(model=args.model or DEFAULT_MODEL, host=host).list_models()
        except Exception as exc:  # noqa: BLE001
            print(f"error: cannot reach Ollama: {exc}", file=sys.stderr)
            return 2
        print("\n".join(models) if models else "(no models installed)")
        return 0

    if not (args.problem or args.input):
        print("error: provide --input (and --output) or --problem", file=sys.stderr)
        return 2
    if args.input and not args.output:
        print("error: --output is required with --input", file=sys.stderr)
        return 2

    cfg = build_config(args)
    explicit_model = bool(args.model or os.environ.get("OLLAMA_MODEL"))
    if args.verbose:
        print(f"[cfg] model={cfg.model} host={cfg.host} profile={cfg.profile} "
              f"samples={cfg.samples} think={cfg.think} pot={cfg.use_pot}", file=sys.stderr)

    try:
        resolve_model(cfg, explicit_model, args.verbose)
    except OllamaError as exc:
        print(f"[error] {exc}", file=sys.stderr)
        print("[error] falling back to deterministic/format-only answers (expect low accuracy).",
              file=sys.stderr)

    log_dir = cfg.log_dir
    if args.problem:
        log_dir = os.path.join(log_dir, "adhoc")
    log = RunLog(log_dir, filename=args.log_file, verbose=args.verbose)
    agent = Agent(cfg, log)
    if args.verbose:
        print(f"[cfg] log={log.path}", file=sys.stderr)

    started = time.time()
    try:
        if args.problem:
            result = agent.solve_problem(args.problem, pid="adhoc")
            print(json.dumps({"id": "adhoc", "answer": result["answer"]}, ensure_ascii=False))
            if args.verbose:
                print(json.dumps({k: result[k] for k in ("confidence", "source", "calls", "seconds")},
                                 ensure_ascii=False), file=sys.stderr)
            return 0

        items, was_single = load_input(args.input)
        outputs: List[Dict[str, Any]] = []
        for idx, item in enumerate(items, 1):
            if time.time() - started > cfg.total_budget:
                print(f"[warn] total budget ({cfg.total_budget:.0f}s) exhausted after {idx - 1} problems; "
                      f"writing partial results", file=sys.stderr)
                break
            pid = item.get("id", f"q{idx}")
            problem = item.get("problem") or item.get("question") or ""
            if not isinstance(problem, str) or not problem.strip():
                outputs.append({"id": pid, "answer": ""})
            else:
                result = agent.solve_problem(problem, pid=str(pid))
                outputs.append({"id": pid, "answer": result["answer"]})
            # progressive write: a batch timeout still leaves valid partial results
            if len(items) > 1:
                write_output(args.output, outputs if not (was_single and len(outputs) == 1) else outputs[0])
        payload = outputs[0] if (was_single and len(outputs) == 1) else outputs
        write_output(args.output, payload)

        summary = log.summary()
        print(json.dumps({
            "input": args.input,
            "output": args.output,
            "problems": len(items),
            "model": cfg.model,
            "seconds": round(time.time() - started, 1),
            "calls": summary.get("total_calls", 0),
            "avg_calls": summary.get("avg_calls", 0),
            "log": log.path,
        }, ensure_ascii=False))
        return 0
    finally:
        log.close()


if __name__ == "__main__":
    sys.exit(main())
