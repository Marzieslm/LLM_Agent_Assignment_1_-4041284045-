"""The agent pipeline.

Per problem:

    1. deterministic format detection            (free)
    2. Planner: text -> structured JSON spec     (1 LLM call, no thinking)
    3. exact solver on the spec                  (free, exact)
    4. one independent chain-of-thought sample   (1 LLM call)
    5. if they disagree / spec invalid / answer ambiguous:
           program-of-thought + extra CoT samples (self-consistency)
    6. if still unsure: critic/verifier pass      (1 LLM call)
    7. weighted vote -> strict answer formatting

Typical case: 2 model calls and an exact answer.  Hard case: at most ~6 calls.
This keeps accuracy high while respecting the exercise's call/time tie-breakers.
"""
from __future__ import annotations

import re
import sys
import time
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .config import Config
from .consistency import Candidate, Decision, agreement, low_confidence, make_candidate, vote
from .formatting import (FormatSpec, canonical, clean_text, collapse_ws, detect_format,
                         extract_final_text, looks_valid, normalize_space_label, render,
                         to_ascii_digits)
from .formalize import formalize_spec
from .ollama_client import OllamaClient, OllamaError
from .pot import extract_code, run_code, CodeRejected
from .prompts import pot_messages, solve_messages, verify_messages
from .solvers import solve
from .trace import RunLog

SOLVE_STYLES_ROTATION = ["direct", "decompose", "independent", "extremes", "constructive"]


def merge_format(regex_fmt: FormatSpec, llm_fmt: Dict[str, Any], problem: str) -> FormatSpec:
    """Combine the deterministic reading with the model's reading.

    Explicit instructions in the text (``Label=<integer>``, ``only the letter``,
    numbered options, ``three digit code``) are unambiguous, so they win.  The model's
    reading is used when the text does not state a shape or to fill in option lists.
    """
    llm = FormatSpec(
        type=str(llm_fmt.get("type") or "text"),
        labels=list(llm_fmt.get("labels") or []),
        choices=list(llm_fmt.get("choices") or []),
        digits=int(llm_fmt.get("digits") or 0),
        instruction=str(llm_fmt.get("instruction") or ""),
    )
    if llm.type not in {"integer", "letter", "choice", "labeled", "code", "text"}:
        llm.type = "text"

    # 1) explicit placeholder list -> labeled, in the order written in the problem
    if regex_fmt.type == "labeled" and len(regex_fmt.labels) >= 2:
        return FormatSpec(type="labeled", labels=list(regex_fmt.labels),
                          instruction=regex_fmt.instruction or llm.instruction)
    # 2) explicit code / letter / integer instructions
    if regex_fmt.type == "code":
        return FormatSpec(type="code", digits=regex_fmt.digits or llm.digits or 3,
                          instruction=regex_fmt.instruction or llm.instruction)
    if regex_fmt.type == "letter":
        return FormatSpec(type="letter", instruction=regex_fmt.instruction or llm.instruction)
    if regex_fmt.type == "integer":
        return FormatSpec(type="integer", instruction=regex_fmt.instruction or llm.instruction)
    # 3) enumerated options
    if regex_fmt.type == "choice" and len(regex_fmt.choices) >= 2:
        choices = llm.choices if len(llm.choices) >= 2 else list(regex_fmt.choices)
        return FormatSpec(type="choice", choices=choices, instruction=llm.instruction)
    # 4) otherwise prefer the model's specific reading
    if llm.type != "text":
        if llm.type == "labeled" and len(llm.labels) < 2:
            llm.type = "integer" if regex_fmt.type != "labeled" else "text"
        if llm.type == "choice" and len(llm.choices) < 2:
            llm.type = "integer" if regex_fmt.type == "integer" else "text"
        if llm.type != "text":
            return llm
    if regex_fmt.type != "text":
        return FormatSpec(type=regex_fmt.type, labels=list(regex_fmt.labels),
                          choices=list(regex_fmt.choices), digits=regex_fmt.digits,
                          instruction=regex_fmt.instruction)
    # 5) last resort: a "how many" question is almost always an integer
    if re.search(r"چند|how many|count", problem) and re.search(r"\d", problem):
        return FormatSpec(type="integer", instruction="inferred from the question")
    return FormatSpec(type="text", instruction=llm.instruction)


class Agent:
    def __init__(self, cfg: Config, log: Optional[RunLog] = None) -> None:
        self.cfg = cfg
        self.client = OllamaClient(
            model=cfg.model,
            host=cfg.host,
            timeout=cfg.call_timeout,
            retries=cfg.retries,
            cache_dir=cfg.cache_dir,
            use_cache=cfg.use_cache,
            verbose=cfg.verbose,
            num_ctx=cfg.num_ctx,
            keep_alive=cfg.keep_alive,
        )
        self.log = log
        self.think_solve = self.client.decide_think(cfg.think)
        self._problem_started = 0.0
        self._calls_at_start = 0

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _format_example(fmt: FormatSpec) -> str:
        if fmt.type == "integer":
            return "<integer>"
        if fmt.type == "letter":
            return "<single letter>"
        if fmt.type == "code":
            return "<" + "d" * (fmt.digits or 3) + ">"
        if fmt.type == "labeled" and fmt.labels:
            return ", ".join(f"{label}=<int>" for label in fmt.labels)
        if fmt.type == "choice":
            return "<one option exactly as listed>"
        return "<answer>"

    def _elapsed_problem(self) -> float:
        return time.time() - self._problem_started

    def _calls_used(self) -> int:
        return self.client.stats.calls - self._calls_at_start

    def _budget_left(self) -> bool:
        return self._elapsed_problem() < self.cfg.problem_timeout

    def _chat(self, messages, *, temperature, max_tokens, think, tag):
        return self.client.chat(
            messages,
            temperature=temperature,
            top_p=self.cfg.top_p,
            top_k=self.cfg.top_k,
            max_tokens=max_tokens,
            think=think,
            seed=self.cfg.seed,
            tag=f"{tag}",
        )

    def _cot(self, problem: str, fmt: FormatSpec, style: str, tag: str = "cot",
             temperature: Optional[float] = None, max_tokens: Optional[int] = None) -> Candidate:
        try:
            res = self._chat(
                solve_messages(problem, fmt.describe(), style=style, example=self._format_example(fmt)),
                temperature=self.cfg.temperature if temperature is None else temperature,
                max_tokens=self.cfg.max_tokens_solve if max_tokens is None else max_tokens,
                think=self.think_solve,
                tag=f"{tag}:{style}",
            )
            text = extract_final_text(res["content"])
            if not text and res.get("thinking"):
                # some hybrid models put everything in the thinking channel
                text = extract_final_text(res["thinking"])
            cand = make_candidate(text, "cot", fmt, detail=style)
            if cand.canonical is None:
                cand.ok = False
            return cand
        except Exception as exc:  # noqa: BLE001
            return Candidate(text="", source="cot", ok=False, detail=f"{style}: {exc}")

    def _pot(self, problem: str, fmt: FormatSpec, tag: str = "pot") -> List[Candidate]:
        out: List[Candidate] = []
        for k in range(max(1, self.cfg.pot_samples)):
            try:
                res = self._chat(
                    pot_messages(problem, fmt.describe()),
                    temperature=0.2,
                    max_tokens=self.cfg.max_tokens_solve,
                    think=False,
                    tag=f"{tag}#{k + 1}",
                )
                code = extract_code(res["content"])
                if not code:
                    continue
                answer, err = run_code(code, timeout=20.0)
                if answer:
                    cand = make_candidate(answer, "pot", fmt, detail="program output")
                    if cand.canonical is None:
                        cand.ok = False
                    out.append(cand)
                elif self.cfg.verbose and err:
                    print(f"[pot] program failed: {err}", file=sys.stderr)
            except CodeRejected as exc:
                if self.cfg.verbose:
                    print(f"[pot] rejected code: {exc}", file=sys.stderr)
            except Exception as exc:  # noqa: BLE001
                if self.cfg.verbose:
                    print(f"[pot] error: {exc}", file=sys.stderr)
        return out

    def _verify(self, problem: str, fmt: FormatSpec, cands: Sequence[Candidate]) -> Candidate:
        top: List[Dict[str, Any]] = []
        seen = set()
        for c in sorted(cands, key=lambda c: -c.weight):
            if not c.ok or not c.canonical or c.canonical in seen:
                continue
            seen.add(c.canonical)
            top.append({"answer": c.text, "source": c.source})
            if len(top) >= 4:
                break
        try:
            res = self._chat(
                verify_messages(problem, fmt.describe(), top),
                temperature=0.1,
                max_tokens=self.cfg.max_tokens_solve,
                think=self.think_solve,
                tag="verify",
            )
            text = extract_final_text(res["content"])
            if not text and res.get("thinking"):
                text = extract_final_text(res["thinking"])
            cand = make_candidate(text, "verify", fmt, detail="critic")
            if cand.canonical is None:
                cand.ok = False
            return cand
        except Exception as exc:  # noqa: BLE001
            return Candidate(text="", source="verify", ok=False, detail=str(exc))

    def _fallback_answer(self, fmt: FormatSpec, solved=None, cands: Sequence[Candidate] = ()) -> str:
        for c in cands:
            if c.ok and c.canonical:
                return render(c.text, fmt)
        if solved is not None and solved.ok and solved.answers:
            return render(solved.answers[0], fmt)
        if fmt.type == "integer":
            return "0"
        if fmt.type == "letter":
            return "A"
        if fmt.type == "choice" and fmt.choices:
            return fmt.choices[0]
        if fmt.type == "code":
            return "0" * (fmt.digits or 3)
        return "unknown"

    # ------------------------------------------------------------------ main
    def solve_problem(self, problem: str, pid: str = "") -> Dict[str, Any]:
        started = time.time()
        self._problem_started = started
        self._calls_at_start = self.client.stats.calls
        problem = clean_text(problem)
        fmt_guess = detect_format(problem)
        record: Dict[str, Any] = {"id": pid, "format_regex": fmt_guess.type}

        spec: Dict[str, Any] = {}
        solved = None
        candidates: List[Candidate] = []
        decision: Optional[Decision] = None
        reason = ""
        fmt = fmt_guess

        try:
            spec = formalize_spec(
                self.client,
                problem,
                max_attempts=2,
                temperature=0.0,
                max_tokens=self.cfg.max_tokens_formalize,
                think=False,
                verbose=self.cfg.verbose,
            )
            fmt = merge_format(fmt_guess, spec.get("answer_format", {}), problem)
            record["skill"] = spec.get("skill")
            record["spec"] = {"skill": spec.get("skill"), "data": spec.get("data"),
                              "format": spec.get("answer_format"),
                              "formalize_error": (spec.get("_meta") or {}).get("error", ""),
                              "suspicious_numbers": (spec.get("_meta") or {}).get("suspicious_numbers", [])}

            if spec.get("skill") and spec["skill"] != "other":
                solved = solve(spec["skill"], spec.get("data") or {})
            record["solver_ok"] = bool(solved and solved.ok)
            if solved and solved.ok:
                record["solver_answers"] = solved.answers
                record["solver_detail"] = solved.detail
            elif solved:
                record["solver_error"] = solved.error

            # ---- stage A: exact answer + one independent sampling check
            if solved and solved.ok:
                # Distrust a structured reading whose numbers do not occur in the text
                # (the model hallucinated the familiar public problem) or whose answer is
                # fractional for an integer-shaped question.  Lower its vote weight so the
                # independent samples can overrule it.
                suspicious_numbers = (spec.get("_meta") or {}).get("suspicious_numbers") or []
                fractional = fmt.type in {"integer", "labeled", "code"} and any(
                    re.search(r"\d\.\d", a) for a in solved.answers
                )
                suspicious = bool(suspicious_numbers) or fractional
                exact_weight = 2.0 if suspicious else 5.0
                for ans in solved.answers[:8]:
                    cand = make_candidate(ans, "exact", fmt, detail=solved.detail)
                    cand.weight = exact_weight
                    candidates.append(cand)
                exact_canon = {c.canonical for c in candidates if c.source == "exact" and c.canonical}
                record["fractional_answer"] = fractional
                record["suspicious_numbers"] = suspicious_numbers

                cot = self._cot(problem, fmt, "direct", tag="cot-check", temperature=0.2,
                                max_tokens=self.cfg.max_tokens_check)
                candidates.append(cot)
                agree = bool(cot.ok and cot.canonical in exact_canon)

                if agree and solved.unique:
                    decision = vote(candidates)
                    reason = "exact solver confirmed by independent sample"
                elif not solved.unique:
                    decision = vote(candidates, restrict_to=list(exact_canon))
                    reason = "ambiguous exact answers; voted among valid solutions"
                else:
                    # ---- stage B: exact vs sampled disagreement -> independent votes
                    if self.cfg.use_pot:
                        candidates.extend(self._pot(problem, fmt))
                    decision = vote(candidates)
                    reason = "exact vs sampled disagreement"
                    # ---- stage C: critic pass when still unclear
                    need_verify = low_confidence(decision, min_share=0.55, min_margin=0.1)
                    if not need_verify and decision.canonical != (candidates[0].canonical or ""):
                        need_verify = True
                    if need_verify and self._budget_left():
                        ver = self._verify(problem, fmt, candidates)
                        candidates.append(ver)
                        decision = vote(candidates)
                        reason += " + critic"
            else:
                # ---- no usable spec: pure sampling
                styles = SOLVE_STYLES_ROTATION
                for i in range(max(1, self.cfg.samples)):
                    if not self._budget_left() and i > 0:
                        break
                    candidates.append(self._cot(problem, fmt, styles[i % len(styles)], tag=f"cot{i + 1}"))
                if self.cfg.use_pot:
                    candidates.extend(self._pot(problem, fmt))
                decision = vote(candidates)
                reason = "no usable structured spec: self-consistency vote"
                if low_confidence(decision) and self._budget_left():
                    ver = self._verify(problem, fmt, candidates)
                    candidates.append(ver)
                    decision = vote(candidates)
                    reason += " + critic"
        except OllamaError as exc:
            record["error"] = str(exc)
            reason = f"model error: {exc}"
        except Exception as exc:  # noqa: BLE001 - never crash the batch
            record["error"] = f"{type(exc).__name__}: {exc}"
            reason = f"internal error: {exc}"

        # ---- finalise
        if decision is None:
            decision = vote(candidates) if candidates else Decision(source="none")
        final = ""
        if decision.canonical:
            final = render(decision.answer, fmt)
            if not final:
                final = render(decision.canonical, fmt)
        if not looks_valid(final):
            final = self._fallback_answer(fmt, solved, candidates)

        # sanitise: a single line, no markdown, no prefix
        final = collapse_ws(final.replace("\n", " ")).strip()
        final = re.sub(r"^(final|answer|پاسخ)\s*[:：]\s*", "", final, flags=re.I).strip()
        final = final.strip("\"'`«»").strip()
        if fmt.type == "integer":
            m = re.search(r"-?\d+", to_ascii_digits(final))
            if m:
                final = m.group(0)
            else:
                # the vote produced something that is not a number: use the solver
                final = self._fallback_answer(fmt, solved, candidates)
        elif fmt.type == "letter":
            m = re.search(r"[A-Za-z]", final)
            if m:
                final = m.group(0).upper()
            else:
                final = self._fallback_answer(fmt, solved, candidates)
        elif fmt.type == "code":
            digits = re.sub(r"\D", "", final)
            if digits:
                final = digits
            else:
                final = self._fallback_answer(fmt, solved, candidates)

        elapsed = time.time() - started
        result = {
            "id": pid,
            "answer": final,
            "confidence": round(decision.confidence, 3),
            "source": decision.source,
            "calls": self._calls_used(),
            "seconds": round(elapsed, 2),
            "reason": reason,
            "candidates": [
                {"answer": c.text[:120], "source": c.source, "weight": c.weight, "ok": c.ok}
                for c in candidates
            ],
            "ranking": decision.ranking,
            "format": {"type": fmt.type, "labels": fmt.labels, "choices": fmt.choices, "digits": fmt.digits},
        }
        if self.log:
            result["skill"] = record.get("skill")
            result["spec"] = record.get("spec")
            result["solver_detail"] = record.get("solver_detail")
            result["cross_check"] = record.get("cross_check")
            if record.get("error"):
                result["error"] = record["error"]
            self.log.add(result)
        return result
