"""Answer-format detection, extraction and canonicalisation.

The grading harness compares the ``answer`` field as a string, so the agent has to
emit *exactly* the requested shape: a bare integer, a single letter, one option
string, a three digit code, or a ``Label=value`` list.  This module turns the
format instruction found in the problem plus a candidate answer into that shape,
and provides a canonical form used for voting.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"
_DIGIT_MAP = {ord(c): str(i) for i, c in enumerate(PERSIAN_DIGITS)}
_DIGIT_MAP.update({ord(c): str(i) for i, c in enumerate(ARABIC_DIGITS)})

BAD_PREFIXES = [
    "final answer:", "final:", "answer:", "the answer is", "پاسخ نهایی:", "پاسخ:", "جواب:", "جواب نهایی:",
    "نتیجه:", "output:", "code:", "the code is", "عدد:", "کد:",
]


def to_ascii_digits(text: str) -> str:
    return (text or "").translate(_DIGIT_MAP)


def strip_accents(text: str) -> str:
    """Normalise Persian/Arabic characters that differ only in presentation."""
    text = unicodedata.normalize("NFKC", text or "")
    text = text.replace("ي", "ی").replace("ك", "ک").replace("ۀ", "ه").replace("ـ", "")
    return text


def clean_text(text: str) -> str:
    text = strip_accents(to_ascii_digits(text or ""))
    text = text.replace("\u200c", " ").replace("\u200f", "").replace("\u200e", "")
    return text.replace("\r\n", "\n").replace("\r", "\n")


def collapse_ws(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def strip_markdown(text: str) -> str:
    text = text or ""
    text = re.sub(r"```[a-zA-Z0-9]*\s*", "", text)
    text = text.replace("```", "")
    text = re.sub(r"^\s*[-*•]\s+", "", text, flags=re.M)
    text = text.replace("**", "").replace("__", "").replace("`", "")
    text = re.sub(r"^#+\s*", "", text, flags=re.M)
    return text


def strip_wrapping(text: str) -> str:
    text = (text or "").strip()
    text = text.strip(" \t\n\"'`«»“”"); 
    text = text.rstrip("。.;؛,،")
    return text.strip()


# --------------------------------------------------------------------------- format spec
@dataclass
class FormatSpec:
    type: str = "text"                  # integer | letter | choice | labeled | code | text
    labels: List[str] = field(default_factory=list)
    choices: List[str] = field(default_factory=list)
    digits: int = 0
    separator: str = ", "
    instruction: str = ""

    def describe(self) -> str:
        if self.type == "integer":
            return "a single integer, digits only"
        if self.type == "letter":
            return "a single uppercase letter"
        if self.type == "choice":
            return "exactly one of: " + " | ".join(self.choices)
        if self.type == "labeled":
            return "exactly this shape: " + ", ".join(f"{l}=<number>" for l in self.labels)
        if self.type == "code":
            return f"exactly {self.digits} digits with no separators"
        return "a short final answer"


def _labels_from_instruction(text: str) -> List[str]:
    """Extract ``Label=<integer>`` style placeholders preserving their order."""
    cleaned = clean_text(text)
    labels: List[str] = []
    # English / transliterated labels
    for m in re.finditer(r"([A-Za-z][A-Za-z0-9_\-]{1,30})\s*=\s*<?\s*integer\s*>?", cleaned, flags=re.I):
        labels.append(m.group(1))
    if labels:
        return labels
    # ``<integer>=Name`` (bidi-mangled variant)
    for m in re.finditer(r"<\s*integer\s*>\s*=\s*([A-Za-z][A-Za-z0-9_\-]{1,30})", cleaned, flags=re.I):
        labels.append(m.group(1))
    return labels


CHOICE_LINE_PATTERNS = [
    r"^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)$",
]


def _choices_from_instruction(text: str) -> List[str]:
    cleaned = clean_text(text)
    # explicit "return exactly one of the following" style lists
    lines = [collapse_ws(l) for l in cleaned.split("\n")]
    opts = []
    for line in lines:
        if not line:
            continue
        if re.fullmatch(r"(Truth|Lie)\s*=\s*[A-Za-zآ-ی][\wآ-ی]*\s*(,\s*(Truth|Lie)\s*=\s*[A-Za-zآ-ی][\wآ-ی]*)*", line):
            opts.append(line)
            continue
        if re.fullmatch(r"(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)", line):
            opts.append(line)
    # de-duplicate, preserve order
    seen, out = set(), []
    for o in opts:
        if o.lower() not in seen:
            seen.add(o.lower())
            out.append(o)
    return out


def detect_format(problem: str, llm_spec: Optional[Dict[str, Any]] = None) -> FormatSpec:
    """Merge the model's requested format with deterministic regex heuristics."""
    problem = clean_text(problem)
    spec = FormatSpec()
    if isinstance(llm_spec, dict):
        spec.type = str(llm_spec.get("type") or "text").lower()
        spec.labels = [str(x) for x in (llm_spec.get("labels") or [])]
        spec.choices = [str(x) for x in (llm_spec.get("choices") or [])]
        spec.digits = int(llm_spec.get("digits") or 0)
        spec.instruction = str(llm_spec.get("instruction") or "")
    if spec.type not in {"integer", "letter", "choice", "labeled", "code", "text"}:
        spec.type = "text"

    # Deterministic reinforcement (the LLM may miss bidi / Persian phrasing).
    low = problem.lower()
    if (
        re.search(r"فقط\s+عدد\s+صحیح", problem)
        or re.search(r"فقط\s+(یکی\s+از\s+)?اعداد", problem)
        or re.search(r"فقط\s+عدد", problem)
        or "only the integer" in low
        or "only integer" in low
        or "only the number" in low
    ):
        if spec.type in {"text", "integer"}:
            spec.type = "integer"
    if re.search(r"فقط\s+حرف", problem):
        spec.type = "letter"
    if re.search(r"فقط\s+(یکی\s+از\s+)?(این\s+)?(چهار|سه|دو)\s+عبارت", problem) and not spec.choices:
        ch = _choices_from_instruction(problem)
        if ch:
            spec.type, spec.choices = "choice", ch
    if re.search(r"کد\s+سه\s*[-\s]?\s*رقمی|سه\s*رقمی", problem):
        spec.type, spec.digits = "code", 3
    if spec.type == "text":
        ch = _choices_from_instruction(problem)
        if len(ch) >= 2:
            spec.type, spec.choices = "choice", ch
    if spec.type == "text" or (spec.type == "labeled" and not spec.labels):
        labels = _labels_from_instruction(problem)
        if labels:
            spec.type, spec.labels = "labeled", labels
    if spec.type == "choice" and not spec.choices:
        spec.choices = _choices_from_instruction(problem)
    if not spec.labels and spec.type == "labeled":
        spec.labels = _labels_from_instruction(problem)
    if spec.type == "labeled" and not spec.labels:
        spec.type = "text"
    return spec


# --------------------------------------------------------------------------- extraction
FINAL_MARKERS = [
    "final answer", "final:", "answer:", "پاسخ نهایی", "پاسخ:", "جواب نهایی", "جواب:",
    "the answer is", "answer is", "نتیجه:", "output:",
]


def extract_final_text(raw: str) -> str:
    """Best-effort isolation of the answer from a reasoning transcript."""
    text = strip_markdown(clean_text(raw or ""))
    if not text.strip():
        return ""
    lines = [collapse_ws(l) for l in text.split("\n")]
    lines = [l for l in lines if l]
    if not lines:
        return ""

    # 1) explicit marker, prefer the last one
    for i in range(len(lines) - 1, -1, -1):
        low = lines[i].lower()
        for marker in FINAL_MARKERS:
            if low.startswith(marker) or f" {marker}" in low:
                rest = lines[i][low.find(marker) + len(marker):].lstrip(" :：=-—")
                if i + 1 < len(lines) and not rest:
                    rest = lines[i + 1]
                if rest.strip():
                    return strip_wrapping(rest)

    # 2) otherwise: last line that looks like an answer payload
    for line in reversed(lines):
        cand = strip_wrapping(line)
        if not cand:
            continue
        if re.fullmatch(r"-?\d+(?:[.,]\d+)?", cand.replace(" ", "")):
            return cand
        if re.fullmatch(r"[A-Ea-e]", cand):
            return cand.upper()
        if re.search(r"[=\-]\s*\d", cand) and len(cand) < 120:
            return cand
        if len(cand) <= 60 and not cand.endswith((".", "؟", "?")):
            return cand
    return strip_wrapping(lines[-1])


# --------------------------------------------------------------------------- canonicalise
def _num(value: Any) -> Optional[str]:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if abs(value - round(value)) < 1e-9:
            return str(int(round(value)))
        return repr(value)
    try:
        from fractions import Fraction

        f = Fraction(value)
        if f.denominator == 1:
            return str(f.numerator)
        return f"{float(f):g}"
    except Exception:
        return None


def normalize_space_label(text: str) -> str:
    text = clean_text(text)
    text = text.replace("：", ":")
    text = re.sub(r"\s*=\s*", "=", text)
    text = re.sub(r"\s*,\s*", ", ", text)
    return collapse_ws(text)


def canonical(value: str, fmt: FormatSpec) -> Optional[str]:
    """Canonical comparison form; ``None`` when the value does not fit the format."""
    raw = collapse_ws(clean_text(value or ""))
    if not raw:
        return None
    if fmt.type == "integer":
        return _canon_integer(raw)
    if fmt.type == "letter":
        return _canon_letter(raw)
    if fmt.type == "code":
        digits = re.sub(r"\D", "", raw)
        if fmt.digits and len(digits) != fmt.digits:
            return None
        return digits or None
    if fmt.type == "labeled":
        pairs = parse_pairs(raw, fmt.labels)
        if not pairs:
            return None
        return ";".join(f"{l}={pairs[l]}" for l in fmt.labels if l in pairs)
    if fmt.type == "choice":
        return _canon_choice(raw, fmt.choices)
    return raw.lower()


def _canon_integer(raw: str) -> Optional[str]:
    text = raw.replace(",", "").replace("٬", "").replace(" ", "")
    m = re.search(r"-?\d+", text)
    if m:
        return str(int(m.group(0)))
    m = re.search(r"-?\d+", raw)
    return str(int(m.group(0))) if m else None


def _canon_letter(raw: str) -> Optional[str]:
    m = re.search(r"\b([A-Za-z])\b", raw)
    if m:
        return m.group(1).upper()
    m = re.search(r"[A-Za-z]", raw)
    return m.group(0).upper() if m else None


def _canon_pairs_parts(text: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for m in re.finditer(r"([A-Za-zآ-ی][\wآ-ی\- ]{0,30}?)\s*[=:]\s*([A-Za-zآ-ی0-9][\wآ-ی ]{0,30})", text):
        key = collapse_ws(m.group(1)).strip()
        val = collapse_ws(m.group(2)).strip()
        out[key.lower()] = val
    return out


def _canon_choice(raw: str, choices: List[str]) -> Optional[str]:
    if not choices:
        return normalize_space_label(raw).lower()
    cand = normalize_space_label(raw)
    norm_cand = cand.lower().strip(" .\"'")
    # exact / containment match first
    for ch in choices:
        n = normalize_space_label(ch).lower()
        if norm_cand == n or n in norm_cand or norm_cand in n:
            return n
    # pair-set comparison (Truth=Bita, Lie=Ali  <->  Lie=Ali, Truth=Bita)
    cand_pairs = _canon_pairs_parts(cand)
    if cand_pairs:
        for ch in choices:
            ch_pairs = _canon_pairs_parts(ch)
            if ch_pairs and len(ch_pairs) == len(cand_pairs) and all(
                cand_pairs.get(k) and cand_pairs[k].lower() == v.lower() for k, v in ch_pairs.items()
            ):
                return normalize_space_label(ch).lower()
    # token overlap fallback
    best, best_score = None, 0.0
    toks = set(re.findall(r"[a-zآ-ی0-9]+", norm_cand))
    for ch in choices:
        ct = set(re.findall(r"[a-zآ-ی0-9]+", normalize_space_label(ch).lower()))
        if not ct:
            continue
        score = len(toks & ct) / len(ct | toks)
        if score > best_score:
            best, best_score = normalize_space_label(ch).lower(), score
    return best if best_score >= 0.5 else None


def parse_pairs(raw: str, labels: Iterable[str]) -> Dict[str, str]:
    """Parse ``Label=value`` pairs, tolerating Persian labels and <integer> noise."""
    text = normalize_space_label(raw)
    pairs: Dict[str, str] = {}
    labels = list(labels)
    for label in labels:
        # exact label
        m = re.search(rf"(?<![\wآ-ی]){re.escape(label)}\s*[=:]\s*(-?\d+(?:\.\d+)?)", text, flags=re.I)
        if m:
            pairs[label] = str(int(float(m.group(1))))
            continue
        # label followed by value with stray characters
        m = re.search(rf"{re.escape(label)}\D{{0,6}}?(-?\d+)", text, flags=re.I)
        if m:
            pairs[label] = str(int(m.group(1)))
    if not pairs:
        # positional fallback: numbers in order
        nums = re.findall(r"-?\d+", text)
        if len(nums) == len(labels):
            for label, n in zip(labels, nums):
                pairs[label] = str(int(n))
    return pairs


def render(value: Any, fmt: FormatSpec) -> str:
    """Render a canonical value in the exact requested output shape."""
    if isinstance(value, (int, float)) or value is None:
        sval = _num(value) or str(value)
    else:
        sval = str(value)
    if fmt.type == "integer":
        c = _canon_integer(sval)
        return c if c is not None else sval.strip()
    if fmt.type == "letter":
        c = _canon_letter(sval)
        return c if c else sval.strip().upper()
    if fmt.type == "code":
        digits = re.sub(r"\D", "", sval)
        return digits
    if fmt.type == "labeled":
        pairs = parse_pairs(sval, fmt.labels)
        if pairs:
            return fmt.separator.join(f"{l}={pairs[l]}" for l in fmt.labels if l in pairs)
        return sval.strip()
    if fmt.type == "choice":
        c = _canon_choice(sval, fmt.choices)
        if c:
            for ch in fmt.choices:
                if normalize_space_label(ch).lower() == c:
                    return normalize_space_label(ch)
        return sval.strip()
    return sval.strip()


def answer_value_from_solver(skill: str, payload: Any) -> str:
    """Turn a solver payload into a renderable string."""
    if isinstance(payload, dict):
        return ", ".join(f"{k}={_num(v) if _num(v) is not None else v}" for k, v in payload.items())
    if isinstance(payload, (list, tuple)):
        return ", ".join(str(x) for x in payload)
    return str(payload)


def looks_valid(answer: str) -> bool:
    a = (answer or "").strip()
    return bool(a) and len(a) <= 200 and not a.lower().startswith(("i cannot", "i'm sorry", "متاسف", "نمی‌توانم"))
