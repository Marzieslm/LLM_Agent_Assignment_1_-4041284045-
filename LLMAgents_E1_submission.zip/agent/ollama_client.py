"""Minimal, dependency-free client for the Ollama HTTP API.

Only the Python standard library is used so the submission runs offline with no
package installations (``requirements.txt`` is therefore intentionally empty).

The client adds behaviour the agent needs:
  * ``think`` handling for hybrid-reasoning models (Qwen3 family) with graceful
    fallback for older Ollama versions / non-thinking models,
  * structured-output requests (JSON schema) with retry on a plain JSON format,
  * retries with exponential backoff, per-call timeout, and an optional disk cache,
  * accounting of calls / tokens / wall-clock so runs can be compared on the
    tie-breaking criteria of the exercise.
"""
from __future__ import annotations

import hashlib
import json
import os
import socket
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


class OllamaError(RuntimeError):
    pass


@dataclass
class LLMStats:
    calls: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    wall_time: float = 0.0
    cache_hits: int = 0
    failures: int = 0
    per_call: List[Dict[str, Any]] = field(default_factory=list)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "calls": self.calls,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "wall_time_s": round(self.wall_time, 2),
            "cache_hits": self.cache_hits,
            "failures": self.failures,
        }


class OllamaClient:
    def __init__(
        self,
        model: str,
        host: str = "http://127.0.0.1:11434",
        timeout: float = 240.0,
        retries: int = 2,
        cache_dir: Optional[str] = None,
        use_cache: bool = True,
        verbose: bool = False,
        num_ctx: int = 8192,
        keep_alive: str = "30m",
    ) -> None:
        self.model = model
        self.host = host.rstrip("/")
        self.timeout = timeout
        self.retries = retries
        self.cache_dir = cache_dir
        self.use_cache = bool(use_cache and cache_dir)
        self.verbose = verbose
        self.num_ctx = num_ctx
        self.keep_alive = keep_alive
        self.stats = LLMStats()
        self._think_supported: Optional[bool] = None
        if self.use_cache:
            os.makedirs(self.cache_dir, exist_ok=True)

    # ------------------------------------------------------------------ HTTP
    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.host}{path}"
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            body = resp.read().decode("utf-8", errors="replace")
        return json.loads(body)

    def list_models(self) -> List[str]:
        try:
            with urllib.request.urlopen(f"{self.host}/api/tags", timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="replace"))
            return [m.get("name", "") for m in data.get("models", [])]
        except Exception:
            return []

    def ensure_available(self) -> None:
        models = self.list_models()
        if not models:
            raise OllamaError(
                f"Ollama is not reachable at {self.host}. Start it with `ollama serve` and pull the model."
            )
        if self.model in models:
            return
        # accept implicit `:latest` naming
        if f"{self.model}:latest" in models:
            return
        # strict: do not silently swap models, but give a helpful message
        raise OllamaError(
            f"Model '{self.model}' is not installed. Installed: {', '.join(sorted(models))}. "
            f"Run `ollama pull {self.model}` or pass --model <installed-model>."
        )

    # ------------------------------------------------------------------ cache
    def _cache_key(self, payload: Dict[str, Any]) -> str:
        blob = json.dumps({"host": self.host, "payload": payload}, ensure_ascii=False, sort_keys=True)
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:32]

    def _cache_get(self, key: str) -> Optional[Dict[str, Any]]:
        if not self.use_cache:
            return None
        path = os.path.join(self.cache_dir, key + ".json")
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return None
        return None

    def _cache_put(self, key: str, value: Dict[str, Any]) -> None:
        if not self.use_cache:
            return
        try:
            path = os.path.join(self.cache_dir, key + ".json")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(value, f, ensure_ascii=False)
            os.replace(tmp, path)
        except Exception:
            pass

    # ------------------------------------------------------------------ chat
    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        temperature: float = 0.7,
        top_p: float = 0.95,
        top_k: int = 0,
        max_tokens: int = 2048,
        think: Optional[bool] = None,
        json_schema: Optional[Dict[str, Any]] = None,
        json_mode: bool = False,
        seed: Optional[int] = None,
        stop: Optional[List[str]] = None,
        tag: str = "",
    ) -> Dict[str, Any]:
        """Return ``{"content", "thinking", "eval_count", "done_reason", "raw"}``."""
        options: Dict[str, Any] = {
            "temperature": temperature,
            "top_p": top_p,
            "num_ctx": self.num_ctx,
            "num_predict": max_tokens,
        }
        if top_k:
            options["top_k"] = int(top_k)
        if seed is not None:
            options["seed"] = seed
        if stop:
            options["stop"] = stop

        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": options,
            "keep_alive": self.keep_alive,
        }
        if json_schema is not None:
            payload["format"] = json_schema
        elif json_mode:
            payload["format"] = "json"
        if think is not None:
            payload["think"] = bool(think)

        key = self._cache_key(payload)
        cached = self._cache_get(key)
        if cached is not None:
            self.stats.cache_hits += 1
            return cached

        last_exc: Optional[Exception] = None
        for attempt in range(self.retries + 1):
            started = time.time()
            try:
                raw = self._post("/api/chat", payload)
                elapsed = time.time() - started
                msg = raw.get("message", {}) or {}
                result = {
                    "content": msg.get("content", "") or "",
                    "thinking": msg.get("thinking", "") or "",
                    "eval_count": raw.get("eval_count", 0) or 0,
                    "prompt_eval_count": raw.get("prompt_eval_count", 0) or 0,
                    "done_reason": raw.get("done_reason", ""),
                    "model": raw.get("model", self.model),
                }
                self.stats.calls += 1
                self.stats.wall_time += elapsed
                self.stats.prompt_tokens += result["prompt_eval_count"]
                self.stats.completion_tokens += result["eval_count"]
                self.stats.per_call.append(
                    {
                        "tag": tag,
                        "seconds": round(elapsed, 2),
                        "prompt_tokens": result["prompt_eval_count"],
                        "completion_tokens": result["eval_count"],
                        "done_reason": result["done_reason"],
                        "think": payload.get("think"),
                    }
                )
                if self.verbose:
                    print(
                        f"[llm] {tag or 'chat'} {elapsed:.1f}s "
                        f"in={result['prompt_eval_count']} out={result['eval_count']} "
                        f"done={result['done_reason']}",
                        file=sys.stderr,
                    )
                self._cache_put(key, result)
                return result
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    detail = exc.read().decode("utf-8", errors="replace")[:400]
                except Exception:
                    pass
                last_exc = OllamaError(f"HTTP {exc.code}: {detail}")
                # Newer-only payload keys: retry once without them.
                if exc.code == 400 and attempt < self.retries:
                    changed = False
                    if "think" in payload:
                        payload.pop("think", None)
                        self._think_supported = False
                        changed = True
                    if isinstance(payload.get("format"), dict):
                        payload["format"] = "json"
                        changed = True
                    if changed:
                        continue
                if exc.code == 404:
                    raise OllamaError(
                        f"Model '{self.model}' not found on the Ollama server. "
                        f"Run `ollama pull {self.model}`."
                    ) from exc
                if exc.code in (500, 503):
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise last_exc from exc
            except (socket.timeout, TimeoutError) as exc:
                last_exc = OllamaError(f"timeout after {self.timeout}s")
                self.stats.failures += 1
                time.sleep(1.0 * (attempt + 1))
            except (urllib.error.URLError, ConnectionError) as exc:
                last_exc = OllamaError(f"connection error: {exc}")
                self.stats.failures += 1
                time.sleep(1.5 * (attempt + 1))
            except Exception as exc:  # noqa: BLE001 - defensive: never crash the run
                last_exc = exc
                self.stats.failures += 1
                time.sleep(1.0 * (attempt + 1))
        raise OllamaError(f"chat failed after {self.retries + 1} attempts: {last_exc}")

    # ------------------------------------------------------------------ helpers
    def decide_think(self, mode: str) -> bool:
        """Map config ``auto|on|off`` to a boolean for the current model.

        Auto keeps thinking on for small hybrid-reasoning models (where it buys
        accuracy for little time) and turns it off for very large ones, where a
        long thinking trace would dominate the runtime budget of the grading run.
        """
        if mode == "on":
            return True
        if mode == "off":
            return False
        name = self.model.lower()
        hybrid = "qwen3" in name or "deepseek-r1" in name or "reason" in name or "think" in name
        if not hybrid:
            return False
        import re as _re

        m = _re.search(r"(\d+(?:\.\d+)?)\s*b(?:\b|[-_])", name)
        if m:
            size = float(m.group(1))
            if size >= 20:
                return False
            if size <= 3:
                # tiny models spend their whole budget in the thinking channel and add
                # little accuracy here; the exact solver carries the reasoning instead
                return False
        return True
