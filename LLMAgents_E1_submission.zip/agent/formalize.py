"""Turn the model's formalisation into a validated spec and (optionally) retry it.

The formaliser is the only stage that must understand Persian; everything after it
is deterministic.  That is why the retry loop feeds the *solver's* error message
back to the model instead of asking it to reason again from scratch.
"""
from __future__ import annotations

import ast
import json
import re
import sys
from typing import Any, Dict, List, Optional, Tuple

from .formatting import clean_text, to_ascii_digits
from .prompts import formalize_messages
from .solvers import SKILLS, solve


def _balanced_json_slice(text: str) -> Optional[str]:
    start = text.find("{")
    if start < 0:
        return None
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    return None


def _repair(text: str) -> str:
    text = to_ascii_digits(text)
    text = text.replace("\u200c", " ").replace("\u200f", "").replace("\u200e", "")
    text = re.sub(r"```[a-zA-Z]*", "", text).replace("```", "")
    text = text.replace("True", "true").replace("False", "false").replace("None", "null")
    text = re.sub(r",\s*([}\]])", r"\1", text)
    return text.strip()


def parse_json_object(raw: str) -> Optional[Dict[str, Any]]:
    if not raw:
        return None
    candidates = []
    sl = _balanced_json_slice(raw)
    if sl:
        candidates.append(sl)
    candidates.append(raw)
    for cand in candidates:
        for attempt in (cand, _repair(cand)):
            try:
                obj = json.loads(attempt)
                if isinstance(obj, dict):
                    return obj
            except Exception:
                pass
            try:
                obj = ast.literal_eval(attempt)
                if isinstance(obj, dict):
                    return obj
            except Exception:
                pass
    return None


def normalize_spec(obj: Dict[str, Any]) -> Dict[str, Any]:
    skill = str(obj.get("skill") or "other").strip().lower()
    skill = skill.replace("-", "_").replace(" ", "_")
    aliases = {
        "algebra": "linear_algebra", "linear": "linear_algebra", "equations": "linear_algebra",
        "sequence": "ordering", "order": "ordering", "permutation": "ordering",
        "logic": "logic_boxes", "boxes": "logic_boxes", "key_boxes": "logic_boxes",
        "scheduling": "schedule", "project": "schedule", "cpm": "schedule",
        "set": "sets", "inclusion_exclusion": "sets",
        "percent": "percent_chain", "percentage": "percent_chain", "discount": "percent_chain",
        "assign": "assignment", "days": "assignment", "constraint_assignment": "assignment",
        "truth": "truth_tellers", "liars": "truth_tellers", "knights": "truth_tellers",
        "grid": "grid_path", "path": "grid_path", "bfs": "grid_path", "maze": "grid_path",
        "code": "digit_code", "digits": "digit_code", "cipher": "digit_code",
    }
    if skill not in SKILLS:
        skill = aliases.get(skill, "other")
    data = obj.get("data")
    if not isinstance(data, dict):
        data = {}
    # small models sometimes put schema fields next to "data" instead of inside it
    for key in ("items", "tasks", "letters", "variables", "equations", "constraints", "people",
                "slots", "statements", "activities", "sets", "intersections", "total", "ops",
                "initial", "final", "start", "goal", "blocked", "bounds", "pool", "length",
                "distinct", "containers", "exactly_true", "query"):
        if key not in data and key in obj:
            data[key] = obj[key]
    fmt = obj.get("answer_format") or obj.get("format") or {}
    if not isinstance(fmt, dict):
        fmt = {}
    ftype = str(fmt.get("type") or "text").strip().lower()
    if ftype not in {"integer", "letter", "choice", "labeled", "code", "text"}:
        ftype = "text"
    labels = fmt.get("labels") or []
    labels = [str(x).strip() for x in labels if str(x).strip()] if isinstance(labels, (list, tuple)) else []
    choices = fmt.get("choices") or []
    choices = [str(x).strip() for x in choices if str(x).strip()] if isinstance(choices, (list, tuple)) else []
    try:
        digits = int(fmt.get("digits") or 0)
    except Exception:
        digits = 0
    return {
        "skill": skill,
        "data": data,
        "answer_format": {
            "type": ftype,
            "labels": labels,
            "choices": choices,
            "digits": digits,
            "instruction": str(fmt.get("instruction") or ""),
        },
        "question": str(obj.get("question") or ""),
    }


_NUM_RE = re.compile(r"-?\d+(?:[.,]\d+)?")


SKILL_HINTS: List[Tuple[str, str]] = [
    ("percent_chain", r"٪|درصد|تخفیف|افزایش قیمت|کمپین|percent|discount|markup"),
    ("assignment", r"دوشنبه|سه‌شنبه|چهارشنبه|پنج‌شنبه|جمعه|ارائه (?:می‌دهد|دارد)|پژوهشگر|روزهای|"
                   r"monday|tuesday|wednesday|thursday|assigned to (?:a )?(?:day|slot|room)"),
    ("truth_tellers", r"دروغگو|راستگو|همیشه راست|همیشه دروغ|liar|truth-?teller|island"),
    ("digit_code", r"کد\s+(?:سه|چهار|پنج)|رقم|سه‌رقمی|digit|code"),
    ("grid_path", r"مختصات|شبکه|مسدود|خانه|ربات|grid|coordinate|blocked|shortest path"),
    ("schedule", r"روز زمان می‌برد|فعالیت|پروژه|هم‌زمان|پس از پایان|duration|project|activity"),
    ("sets", r"هر دو|هیچ‌کدام|دانشجو|مجموعه|both|neither|students?"),
    ("logic_boxes", r"گزاره|جعبه|دقیقاً یکی|کلید|statement|box|exactly one"),
    ("ordering", r"جایگاه|ترتیب|بلافاصله|اولین|آخرین|قبل از|بعد از|position|immediately|before"),
    ("linear_algebra", r"مجموع|برابر|بیشتر از|کمتر از|نسبت|total|times|more than|sum"),
]


def guess_skill_hint(problem: str) -> str:
    """Cheap keyword prior used only as a hint in the prompt (never as a decision)."""
    text = clean_text(problem).lower()
    scores: Dict[str, int] = {}
    for skill, pattern in SKILL_HINTS:
        hits = len(re.findall(pattern, text))
        if hits:
            scores[skill] = scores.get(skill, 0) + hits
    if not scores:
        return ""
    return max(scores.items(), key=lambda kv: kv[1])[0]



def numbers_in_text(text: str) -> List[str]:
    return [m.group(0).replace(",", "") for m in _NUM_RE.finditer(clean_text(text))]


def echo_check(spec: Dict[str, Any], problem: str) -> List[str]:
    """Soft check: every number used by the spec should literally occur in the text."""
    problem_nums = set(numbers_in_text(problem))
    used: set = set()

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                if k in {"query", "type", "labels", "choices", "instruction", "question", "skill"}:
                    continue
                walk(v)
        elif isinstance(node, (list, tuple)):
            for v in node:
                walk(v)
        elif isinstance(node, bool):
            return
        elif isinstance(node, (int, float)):
            used.add(str(int(node)) if float(node) == int(node) else str(node))
        elif isinstance(node, str):
            for m in _NUM_RE.finditer(node):
                used.add(m.group(0).replace(",", ""))

    walk(spec.get("data", {}))
    # numbers that are structural (positions, indices, counts of items) may be implicit
    suspicious = sorted(n for n in used if n not in problem_nums and n not in {"0", "1", "2", "3", "4", "5"})
    return suspicious


def validate_spec(spec: Dict[str, Any]) -> Tuple[bool, str]:
    skill = spec.get("skill")
    if skill == "other":
        return False, "no specialised skill recognised"
    data = spec.get("data") or {}
    if not isinstance(data, dict) or not data:
        return False, "data object is empty"
    solved = solve(skill, data)
    if not solved.ok:
        return False, f"the structured solver rejected the data: {solved.error}"
    if not solved.answers:
        return False, "the solver produced no answer"
    space = solved.extra.get("search_space")
    if space and space > 8 and len(solved.answers) > 0.8 * space:
        return False, "almost every candidate satisfies the constraints; a constraint is missing"
    if len(solved.answers) > 50:
        return False, "too many solutions; the constraints are probably incomplete"
    return True, ""


def formalize_spec(
    client,
    problem: str,
    *,
    max_attempts: int = 2,
    temperature: float = 0.0,
    max_tokens: int = 1024,
    think: bool = False,
    verbose: bool = False,
) -> Dict[str, Any]:
    """Ask the model for the structured spec, validating and retrying once."""
    feedback = ""
    last_raw = ""
    last_error = ""
    hint = guess_skill_hint(problem)
    for attempt in range(1, max_attempts + 1):
        try:
            res = client.chat(
                formalize_messages(problem, feedback, hint=hint),
                temperature=temperature if attempt == 1 else max(0.2, temperature + 0.2),
                max_tokens=max_tokens,
                think=think,
                json_mode=True,
                tag=f"formalize#{attempt}",
            )
            last_raw = res["content"]
        except Exception as exc:  # noqa: BLE001
            last_error = f"model call failed: {exc}"
            if verbose:
                print(f"[formalize] {last_error}", file=sys.stderr)
            continue
        obj = parse_json_object(last_raw)
        if obj is None:
            last_error = "the output was not valid JSON"
            feedback = last_error
            if verbose:
                print(f"[formalize] {last_error}: {last_raw[:200]!r}", file=sys.stderr)
            continue
        spec = normalize_spec(obj)
        ok, err = validate_spec(spec)
        if ok:
            spec["_meta"] = {
                "attempts": attempt,
                "raw": last_raw,
                "hint": hint,
                "suspicious_numbers": echo_check(spec, problem),
            }
            return spec
        last_error = err
        feedback = err
        if verbose:
            print(f"[formalize] rejected: {err}", file=sys.stderr)
    return {
        "skill": "other",
        "data": {},
        "answer_format": {"type": "text", "labels": [], "choices": [], "digits": 0, "instruction": ""},
        "question": "",
        "_meta": {"attempts": max_attempts, "raw": last_raw, "hint": hint, "error": last_error},
    }
