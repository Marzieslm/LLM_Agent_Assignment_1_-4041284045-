"""Program-of-thought: let the model write a Python solver, then run it safely.

Small models often get arithmetic wrong while their *program* is right, and a
program's output can be verified.  The generated code is parsed with :mod:`ast`
against a strict allow-list (no imports outside the standard math/iteration
modules, no file, network or process access) and executed in a subprocess with a
timeout, isolated mode and a minimal environment.
"""
from __future__ import annotations

import ast
import os
import re
import subprocess
import sys
import tempfile
from typing import Optional, Tuple

ALLOWED_IMPORTS = {
    "math", "fractions", "itertools", "collections", "re", "string", "decimal",
    "statistics", "operator", "functools", "heapq", "bisect", "array", "random",
}
ALLOWED_NAMES = {
    "print", "range", "len", "int", "float", "str", "list", "tuple", "set", "dict", "sorted",
    "sum", "min", "max", "abs", "round", "enumerate", "zip", "map", "filter", "reversed",
    "any", "all", "bool", "divmod", "pow", "frozenset", "chr", "ord", "True", "False", "None",
    "int", "float", "complex",
}
FORBIDDEN_ATTRS = {
    "system", "popen", "spawn", "exec", "eval", "compile", "__import__", "open", "remove",
    "unlink", "rmdir", "makedirs", "write", "send", "connect", "socket", "kill", "fork",
}
ALLOWED_DUNDERS = {"__name__", "__doc__", "__main__", "__file__"}


def extract_code(raw: str) -> str:
    if not raw:
        return ""
    m = re.search(r"```(?:python3?|py)?\s*\n(.*?)```", raw, flags=re.S | re.I)
    if m:
        return m.group(1).strip("\n")
    # fallback: from the first import/def/for/print to the end
    lines = raw.splitlines()
    start = None
    for i, line in enumerate(lines):
        if re.match(r"\s*(import |from |def |for |while |print\(|nums|ans|code)", line):
            start = i
            break
    if start is not None:
        return "\n".join(lines[start:]).strip("\n")
    return ""


class CodeRejected(ValueError):
    pass


def check_code(code: str) -> None:
    if not code.strip():
        raise CodeRejected("empty program")
    if len(code) > 6000:
        raise CodeRejected("program too long")
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        raise CodeRejected(f"syntax error: {exc.msg}") from exc
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            mods = []
            if isinstance(node, ast.Import):
                mods = [a.name.split(".")[0] for a in node.names]
            else:
                mods = [(node.module or "").split(".")[0]]
            for mod in mods:
                if mod not in ALLOWED_IMPORTS:
                    raise CodeRejected(f"import of '{mod}' is not allowed")
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            if node.id.startswith("__") and node.id not in ALLOWED_DUNDERS:
                raise CodeRejected("dunder names are not allowed")
        if isinstance(node, ast.Attribute):
            if node.attr.startswith("__") or node.attr in FORBIDDEN_ATTRS:
                raise CodeRejected(f"attribute '{node.attr}' is not allowed")
        if isinstance(node, ast.Call):
            fn = node.func
            if isinstance(fn, ast.Name) and fn.id in {
                "eval", "exec", "compile", "open", "input", "globals", "locals", "vars",
                "getattr", "setattr", "delattr", "breakpoint", "memoryview", "help", "exit", "quit",
            }:
                raise CodeRejected(f"call to '{fn.id}' is not allowed")
            if isinstance(fn, ast.Name) and fn.id == "__import__":
                raise CodeRejected("__import__ is not allowed")
    if re.search(r"\b(import\s+os|import\s+sys|import\s+subprocess|import\s+socket|import\s+shutil|"
                 r"import\s+pathlib|import\s+ctypes|import\s+urllib|import\s+requests)", code):
        raise CodeRejected("forbidden module")


def run_code(code: str, timeout: float = 20.0) -> Tuple[Optional[str], str]:
    """Execute the program and return (last printed line, error)."""
    check_code(code)
    tmpdir = tempfile.mkdtemp(prefix="pot_")
    path = os.path.join(tmpdir, "solver.py")
    with open(path, "w", encoding="utf-8") as f:
        f.write(code)
    env = {
        "PYTHONIOENCODING": "utf-8",
        "PYTHONUTF8": "1",
        "PATH": os.environ.get("PATH", ""),
        "SYSTEMROOT": os.environ.get("SYSTEMROOT", ""),
        "TEMP": tmpdir,
        "TMP": tmpdir,
    }
    try:
        proc = subprocess.run(
            [sys.executable, "-I", "-S", path],
            cwd=tmpdir,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return None, f"program timed out after {timeout:.0f}s"
    finally:
        pass
    if proc.returncode != 0:
        err = (proc.stderr or "").strip().splitlines()
        return None, f"program failed: {err[-1] if err else 'unknown error'}"
    out = (proc.stdout or "").strip()
    if not out:
        return None, "program printed nothing"
    if len(out) > 20000:
        return None, "program produced too much output"
    lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
    return (lines[-1] if lines else None), ""
