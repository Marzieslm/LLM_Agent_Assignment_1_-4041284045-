"""Prompt templates for the Planner / Solver / Verifier stages.

The problems are Persian, so every prompt tells the model to read the original text
carefully while doing its internal reasoning in English (which small models handle
more reliably).  Output contracts are explicit and short.
"""
from __future__ import annotations

from typing import Any, Dict, List, Sequence

SYSTEM = (
    "You are a precise reasoning assistant inside an automated solver. "
    "You read problems in Persian (Farsi) and reason in English. "
    "You never invent facts that are not in the problem, and you always respect the "
    "requested output format exactly. Internal reasoning is private; the caller only "
    "consumes the final line."
)

SKILL_DOC = """\
Skills and the "data" object each expects (keep every name/number from the problem):

1. linear_algebra — totals and linear relations.
   {"variables":["Reza","Sara","Nima"],
    "equations":[{"coeffs":{"Reza":1,"Sara":1,"Nima":1},"rhs":72},
                 {"coeffs":{"Nima":1,"Reza":-2},"rhs":0},
                 {"coeffs":{"Sara":1,"Reza":-1},"rhs":12}]}
   Each equation means sum(coeff*var)=rhs. "Nima = 2*Reza" is Nima:1, Reza:-2.

2. ordering — one item per position.
   {"items":["A","B","C","D","E"],
    "constraints":[{"type":"before","a":"B","b":"D"},{"type":"immediately_after","a":"A","b":"C"},
                   {"type":"not_first","item":"E"},{"type":"not_last","item":"E"},{"type":"last","item":"D"}],
    "query":{"type":"item_at_position","position":1}}
   types: before, after, immediately_before, immediately_after, first, last, not_first, not_last,
   position(item,position), distance(a,b,d). query: item_at_position, position_of_item, first, last, order.
   DIRECTION: "a before b" = a earlier than b. "a immediately_after b" = b is directly followed by a,
   i.e. "A immediately after C" is {"type":"immediately_after","a":"A","b":"C"}.
   "a immediately_before b" = a is directly followed by b.

3. logic_boxes — exactly N statements true.
   {"containers":["1","2","3"],
    "statements":[{"id":"A","expr":"pos == 2"},{"id":"B","expr":"pos != 2"},{"id":"C","expr":"pos == 1"}],
    "exactly_true":1,"query":"pos"}          ("pos" = 1-based container index)

4. schedule — durations and finish-to-start deps.
   {"activities":[{"name":"design","duration":3,"deps":[]},
                  {"name":"implementation","duration":5,"deps":["design"]},
                  {"name":"legal","duration":4,"deps":[]},
                  {"name":"deployment","duration":2,"deps":["implementation","legal"]}],
    "query":"makespan"}                       (or "finish:<name>", "start:<name>")

5. sets — overlap counting.
   {"total":40,"sets":[{"name":"Python","size":24},{"name":"Java","size":18}],
    "intersections":{"Python,Java":10},"query":"neither"}    (query: neither, union, both)

6. percent_chain — sequential percentage changes.
   {"initial":null,"ops":[{"type":"increase","pct":25},{"type":"decrease","pct":20}],
    "final":600,"query":"initial"}

7. assignment — one slot per person, bijection.
   {"people":["Arman","Bahar","Kourosh","Darya"],"slots":["Monday","Tuesday","Wednesday","Thursday"],
    "constraints":[{"type":"equal","person":"Bahar","slot":"Thursday"},
                   {"type":"not_equal","person":"Darya","slot":"Monday"},
                   {"type":"before","a":"Arman","b":"Kourosh"},
                   {"type":"immediately_after","a":"Kourosh","b":"Darya"}],
    "query":{"type":"slot_of","person":"Arman"}}
   types: equal, not_equal, before, after, immediately_before, immediately_after, position.
   query: slot_of(person), person_at(slot), assignment.
   DIRECTION: "a before b" = a's slot is earlier than b's; "a immediately_after b" = a is exactly
   one slot after b; "a immediately_before b" = a is exactly one slot before b.

8. truth_tellers — everyone always tells the truth or always lies.
   {"people":[{"name":"Ali","statement":"not Bita"},{"name":"Bita","statement":"Ali != Bita"}],
    "query":"types"}   statement = Python boolean expression over names (True = truthful).

9. grid_path — 4-directional grid, shortest path.
   {"start":[0,0],"goal":[4,3],"blocked":[[1,0],[1,1],[1,2]],
    "bounds":{"x":[0,4],"y":[0,3]},"query":"moves"}

10. digit_code — code of distinct digits.
   {"length":3,"pool":[1,2,3,4,5],"distinct":true,
    "constraints":["d1 > d2","d3 == d1 - d2","d1 + d2 + d3 == 8","5 not in [d1,d2,d3]"],
    "query":"code"}                          (digits are d1,d2,d3,... from the left)

11. other — only if none of the above fits (describe it in data).
"""

FORMALIZE_INSTRUCTIONS = """\
Task: TRANSLATE the problem into the JSON schema below. Do NOT solve it.

Output a single JSON object with exactly these keys:
  "skill": one of the skill names,
  "data": the object described for that skill,
  "answer_format": {
      "type": "integer" | "letter" | "choice" | "labeled" | "code" | "text",
      "labels": [..],          // only for "labeled": labels in the requested order
      "choices": [..],         // only for "choice": the exact option strings
      "digits": 3,             // only for "code"
      "instruction": "..."     // short quote of the requested output format
  },
  "question": "what the problem asks, in one English sentence"

ROUTING GUIDE — pick by meaning, not by keyword alone:
  * sequential percentage changes / discount / markup ........ percent_chain
  * people assigned to distinct days, slots, rooms, seats ...... assignment
  * tasks with durations and "after/both finished" deps ....... schedule
  * two groups with overlap, "how many in neither" ............ sets
  * "exactly N of these statements are true", boxes/keys ...... logic_boxes
  * island of truth-tellers and liars ......................... truth_tellers
  * ranking / schedule of items with before-after constraints . ordering
  * grid, coordinates, blocked cells, shortest path ........... grid_path
  * a code made of digits with digit constraints .............. digit_code
  * totals, "k times", "d more than", shares of a sum .......... linear_algebra
Do NOT force linear_algebra on assignment, ordering, scheduling, logic or percentage
problems: each of those has its own skill above.

Rules:
- Copy every number exactly as printed. Persian/Arabic digits must be written as 0-9.
- Never add constraints or numbers that are not in the text.
- Keep entity names exactly as printed (Persian names are fine).
- If the requested output names differ from the names in the story (e.g. the format asks
  for Reza/Sara/Nima), use the requested output names as identifiers in "data" and put
  them in answer_format.labels in the requested order.
- "answer_format.type" must reflect the literal instruction:
    * "only the integer" / "فقط عدد صحیح" -> integer
    * "only the letter" / "فقط حرف" -> letter
    * a list of options -> choice (choices = exact option strings)
    * "Reza=<integer>, Sara=<integer>, Nima=<integer>" -> labeled (labels in that order)
    * "three digit code" / "کد سه رقمی" -> code with digits=3
    * anything else -> text
- Output JSON only. No markdown, no comments.

SHAPE RULES (these are the most frequent mistakes — follow exactly):
- digit_code: "constraints" MUST be a list of Python expression STRINGS over d1..dn:
      ["d1 > d2", "d3 == d1 - d2", "d1 + d2 + d3 == 8", "5 not in [d1, d2, d3]"]
  Never objects such as {"type": "greater_than"}.
- truth_tellers: "statement" MUST be a Python boolean expression over the person names,
  where a name is True if that person tells the truth:
      "not Bita", "Ali != Bita", "Ali and Bita", "Ali == Bita"
  Never natural language like "Bita is a liar".
- ordering: constraints are objects with type before/after/immediately_before/
  immediately_after/first/last/not_first/not_last/position and fields a, b or item.
- assignment: constraints are objects with type equal/not_equal/before/after/
  immediately_before/immediately_after/position and fields person, slot or a, b.
- logic_boxes: each statement expression uses "pos" (1-based box index), e.g. "pos == 2".
- linear_algebra: every symbol used in "equations" must also be listed in "variables".
  Include one equation for the total and one for every relation in the text, so that
  every variable appears and the system has a unique solution. "X is k times Y" is
  X:+1, Y:-k; "X is d more than Y" is X:+1, Y:-1, rhs d.
  If the previous attempt was rejected for free variables you are probably forcing
  linear_algebra where another skill fits — switch the skill.

SKILLS:
{skills}

Example (different numbers from any real exercise):
Problem: "A basket has 3 apples and 4 pears; 2 fruits are both. How many fruits are in the basket?"
Output:
{{"skill":"sets","data":{{"total":9,"sets":[{{"name":"apple","size":3}},{{"name":"pear","size":4}}],"intersections":{{"apple,pear":2}},"query":"union"}},"answer_format":{{"type":"integer","instruction":"only the integer"}},"question":"How many fruits are in the basket?"}}
"""


def formalize_messages(problem: str, feedback: str = "", hint: str = "") -> List[Dict[str, str]]:
    user = FORMALIZE_INSTRUCTIONS.replace("{skills}", SKILL_DOC)
    if hint:
        user += f"\nHint: this problem most likely uses the skill '{hint}'.\n"
    user += "\n\nPROBLEM (original text, may be Persian):\n" + problem.strip()
    if feedback:
        user += ("\n\nThe previous attempt was rejected: " + feedback +
                 "\nFix it — change the skill if the schema does not fit — and output the full JSON again.")
    return [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}]


SOLVE_STYLES = {
    "direct": "Solve the problem directly, step by step, then check your arithmetic.",
    "decompose": "First split the problem into sub-problems, solve each sub-problem, then combine the results.",
    "independent": "Solve the problem twice with two independent methods and compare; resolve any disagreement.",
    "extremes": "Solve the problem, then sanity-check the result against the constraints and the expected magnitude.",
    "constructive": "Enumerate the candidate configurations systematically and eliminate the ones that break a constraint.",
}


def solve_messages(problem: str, fmt_desc: str, style: str = "direct", example: str = "") -> List[Dict[str, str]]:
    instruction = SOLVE_STYLES.get(style, SOLVE_STYLES["direct"])
    example_block = f"\nExample of the last line (shape only): FINAL: {example}\n" if example else ""
    user = f"""\
Solve the following problem. It may be written in Persian; read it carefully.

{problem.strip()}

Method: {instruction}

Required final format: {fmt_desc}.
Rules for the final line:
- End with exactly one line of the form: FINAL: <answer>
- <answer> must contain only the answer itself (no units, no explanation, no quotes,
  no Persian words, no markdown).
- If the format is a list of Label=value pairs, include every label in the requested order.
- Nothing after the FINAL line.
{example_block}"""
    return [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}]


POT_SYSTEM = (
    "You are a code-writing solver. You write short, self-contained Python 3 programs that "
    "compute exact answers. You never use input(), files, the network, or external packages."
)


def pot_messages(problem: str, fmt_desc: str) -> List[Dict[str, str]]:
    user = f"""\
Write a Python 3 program that solves the problem below exactly and prints ONLY the final answer.

{problem.strip()}

Requirements:
- Use only the Python standard library (math, fractions, itertools, collections, re, ...).
- No input(), no reading/writing files, no network, no subprocess, no third-party packages.
- The program must print exactly one line: the final answer in this format: {fmt_desc}.
- Do not print explanations, labels, or extra lines.
- If the problem asks for a count, print the integer. If it asks for a name/option, print that string
  exactly as written in the problem. If it asks for a code, print the digits with no separators.
Output the program inside a single ```python code block.
"""
    return [{"role": "system", "content": POT_SYSTEM}, {"role": "user", "content": user}]


def check_spec_messages(problem: str, spec: Dict[str, Any]) -> List[Dict[str, str]]:
    """Ask the model to proof-read its own structured reading against the text."""
    import json as _json

    payload = _json.dumps({"skill": spec.get("skill"), "data": spec.get("data")},
                          ensure_ascii=False, indent=1)
    user = f"""\
A parser produced the structured reading below for the problem. Proof-read it against the
problem text, line by line.

PROBLEM:
{problem.strip()}

STRUCTURED READING:
{payload}

Check carefully:
- every number against the text;
- negations: "نیست" / "not" must not be dropped, and "است" must not be negated;
- direction of before/after/immediately relations: "A before B" means A is earlier than B;
  "A immediately after B" means B comes directly before A;
- overlaps: "هر دو" / "both" is an intersection, not zero;
- every entity that appears in the text appears in the reading.

If everything matches, output exactly: OK
If something is wrong, output the corrected JSON object (same schema, keys skill/data) and
nothing else. Do not explain.
"""
    return [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}]


def verify_messages(problem: str, fmt_desc: str, candidates: Sequence[Dict[str, Any]]) -> List[Dict[str, str]]:
    lines = []
    for i, c in enumerate(candidates, 1):
        lines.append(f"{i}. {c.get('answer')}   (source: {c.get('source')})")
    user = f"""\
A candidate solver produced the answers below for this problem. Re-solve the problem yourself from
scratch and decide which answer is correct.

{problem.strip()}

Candidates:
{chr(10).join(lines)}

Check every constraint of the problem against each candidate. If all candidates are wrong, compute
the correct answer. Required final format: {fmt_desc}.
End with exactly one line: FINAL: <answer> (nothing after it).
"""
    return [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}]


def repair_json_messages(problem: str, raw: str) -> List[Dict[str, str]]:
    user = f"""\
The JSON below was supposed to describe the problem, but it is invalid or incomplete.
Return a corrected, complete JSON object with the required keys (skill, data, answer_format, question).
Output JSON only.

Problem:
{problem.strip()}

Broken JSON:
{raw[:4000]}
"""
    return [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}]
