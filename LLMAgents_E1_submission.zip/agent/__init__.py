"""Local reasoning agent package (Planner -> exact solver -> verification -> vote)."""
from .config import Config, build_config  # noqa: F401
from .pipeline import Agent  # noqa: F401
