"""Safe evaluation of small arithmetic / boolean constraint expressions.

The formalizer lets the model express CSP conditions as Python-like expressions
(``d1 > d2``, ``d3 == d1 - d2``, ``Ali != Bita``).  Those expressions are never
passed to ``eval``: they are parsed with :mod:`ast` and interpreted node by node
against a whitelist, so arbitrary code cannot run.
"""
from __future__ import annotations

import ast
from fractions import Fraction
from typing import Any, Dict, Iterable

_ALLOWED_NODES = (
    ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not, ast.USub, ast.UAdd,
    ast.BinOp, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow,
    ast.Compare, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn,
    ast.Name, ast.Load, ast.Constant, ast.List, ast.Tuple, ast.Set, ast.IfExp,
    ast.Call, ast.Subscript,
)

_ALLOWED_FUNCS = {"abs", "min", "max", "sum", "len", "all", "any", "sorted", "round"}


class ExprError(ValueError):
    pass


def _check(node: ast.AST) -> None:
    for n in ast.walk(node):
        if not isinstance(n, _ALLOWED_NODES):
            raise ExprError(f"disallowed expression element: {type(n).__name__}")
        if isinstance(n, ast.Call):
            if not isinstance(n.func, ast.Name) or n.func.id not in _ALLOWED_FUNCS:
                raise ExprError("only abs/min/max/sum/len/all/any/sorted/round may be called")
            if n.keywords:
                raise ExprError("keyword arguments are not allowed")
        if isinstance(n, ast.Attribute):
            raise ExprError("attribute access is not allowed")
        if isinstance(n, ast.Constant) and isinstance(n.value, str):
            # string constants are allowed (used for day/slot equality)
            continue


def _eval(node: ast.AST, env: Dict[str, Any]) -> Any:
    if isinstance(node, ast.Expression):
        return _eval(node.body, env)
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        if node.id not in env:
            raise ExprError(f"unknown name '{node.id}'")
        return env[node.id]
    if isinstance(node, ast.List):
        return [_eval(e, env) for e in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_eval(e, env) for e in node.elts)
    if isinstance(node, ast.Set):
        return {_eval(e, env) for e in node.elts}
    if isinstance(node, ast.UnaryOp):
        val = _eval(node.operand, env)
        if isinstance(node.op, ast.Not):
            return not val
        if isinstance(node.op, ast.USub):
            return -val
        return +val
    if isinstance(node, ast.BoolOp):
        vals = [_eval(v, env) for v in node.values]
        return all(vals) if isinstance(node.op, ast.And) else any(vals)
    if isinstance(node, ast.BinOp):
        left, right = _eval(node.left, env), _eval(node.right, env)
        op = node.op
        if isinstance(op, ast.Add):
            return left + right
        if isinstance(op, ast.Sub):
            return left - right
        if isinstance(op, ast.Mult):
            return left * right
        if isinstance(op, ast.Div):
            return Fraction(left) / Fraction(right)
        if isinstance(op, ast.FloorDiv):
            return left // right
        if isinstance(op, ast.Mod):
            return left % right
        if isinstance(op, ast.Pow):
            if abs(right) > 64:
                raise ExprError("exponent too large")
            return left ** right
        raise ExprError("unsupported operator")
    if isinstance(node, ast.Compare):
        left = _eval(node.left, env)
        for op, comp in zip(node.ops, node.comparators):
            right = _eval(comp, env)
            if isinstance(op, ast.Eq):
                ok = left == right
            elif isinstance(op, ast.NotEq):
                ok = left != right
            elif isinstance(op, ast.Lt):
                ok = left < right
            elif isinstance(op, ast.LtE):
                ok = left <= right
            elif isinstance(op, ast.Gt):
                ok = left > right
            elif isinstance(op, ast.GtE):
                ok = left >= right
            elif isinstance(op, ast.In):
                ok = left in right
            elif isinstance(op, ast.NotIn):
                ok = left not in right
            else:  # pragma: no cover
                raise ExprError("unsupported comparison")
            if not ok:
                return False
            left = right
        return True
    if isinstance(node, ast.IfExp):
        return _eval(node.body, env) if _eval(node.test, env) else _eval(node.orelse, env)
    if isinstance(node, ast.Call):
        func = node.func.id
        args = [_eval(a, env) for a in node.args]
        table = {
            "abs": abs,
            "min": min,
            "max": max,
            "sum": sum,
            "len": len,
            "all": all,
            "any": any,
            "sorted": sorted,
            "round": round,
        }
        return table[func](*args)
    if isinstance(node, ast.Subscript):
        return _eval(node.value, env)[_eval(node.slice, env)]
    raise ExprError(f"unsupported expression: {type(node).__name__}")


def evaluate(expr: str, env: Dict[str, Any]) -> Any:
    """Evaluate a whitelisted expression string in ``env``."""
    if not isinstance(expr, str) or not expr.strip():
        raise ExprError("empty expression")
    text = expr.strip()
    if len(text) > 500:
        raise ExprError("expression too long")
    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError as exc:
        raise ExprError(f"syntax error in '{text}': {exc.msg}") from exc
    _check(tree)
    return _eval(tree, env)


def evaluate_bool(expr: str, env: Dict[str, Any]) -> bool:
    return bool(evaluate(expr, env))
