"""Run logging: one JSONL record per problem plus a human-readable summary."""
from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional


class RunLog:
    def __init__(self, directory: str = "logs", filename: Optional[str] = None, verbose: bool = False) -> None:
        os.makedirs(directory, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        self.path = filename or os.path.join(directory, f"run-{stamp}.jsonl")
        self.verbose = verbose
        self.records: List[Dict[str, Any]] = []
        self.started = time.time()
        self._fh = open(self.path, "a", encoding="utf-8")

    def add(self, record: Dict[str, Any]) -> None:
        record = dict(record)
        record.setdefault("ts", round(time.time() - self.started, 3))
        self.records.append(record)
        try:
            self._fh.write(json.dumps(record, ensure_ascii=False) + "\n")
            self._fh.flush()
        except Exception:
            pass
        if self.verbose:
            print(
                f"[{record.get('id','?')}] answer={record.get('answer','')!r} "
                f"conf={record.get('confidence', 0):.2f} calls={record.get('calls', 0)} "
                f"time={record.get('seconds', 0):.1f}s",
                flush=True,
            )

    def close(self) -> None:
        try:
            self._fh.close()
        except Exception:
            pass

    def summary(self) -> Dict[str, Any]:
        if not self.records:
            return {"problems": 0}
        return {
            "problems": len(self.records),
            "total_calls": sum(r.get("calls", 0) for r in self.records),
            "avg_calls": round(sum(r.get("calls", 0) for r in self.records) / len(self.records), 2),
            "total_seconds": round(time.time() - self.started, 1),
            "log_file": self.path,
        }
