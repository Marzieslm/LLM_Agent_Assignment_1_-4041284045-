"""Configuration and small shared utilities for the reasoning agent."""
from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional

DEFAULT_MODEL = "qwen3.8:27b"
DEFAULT_HOST = "http://127.0.0.1:11434"

# Temperature / sampling knobs per profile.  Accuracy first, calls second.
PROFILES = {
    # one cheap structured pass + one confirmation sample
    "fast": dict(samples=3, max_samples=5, pot=1, verify_on_low_confidence=True),
    "balanced": dict(samples=5, max_samples=9, pot=1, verify_on_low_confidence=True),
    "max": dict(samples=9, max_samples=13, pot=2, verify_on_low_confidence=True),
}


@dataclass
class Config:
    model: str = DEFAULT_MODEL
    host: str = DEFAULT_HOST
    profile: str = "balanced"

    # generation
    temperature: float = 0.7
    top_p: float = 0.95
    top_k: int = 0            # 0 = do not send; LFM3 recommends 20 for math, 50 for chat
    num_ctx: int = 8192
    max_tokens_solve: int = 1024
    max_tokens_formalize: int = 768
    max_tokens_check: int = 768
    think: str = "auto"          # auto | on | off
    seed: int = 20261112

    # orchestration
    samples: int = 5
    max_samples: int = 9
    pot_samples: int = 1
    use_pot: bool = True
    use_cache: bool = True
    cache_dir: str = ".cache/llm"
    call_timeout: float = 240.0
    problem_timeout: float = 420.0
    total_budget: float = 5400.0
    retries: int = 2

    # output
    verbose: bool = False
    log_dir: str = "logs"
    log_file: Optional[str] = None
    keep_alive: str = "30m"

    extra: Dict[str, Any] = field(default_factory=dict)

    def apply_profile(self) -> "Config":
        prof = PROFILES.get(self.profile)
        if prof:
            self.samples = int(prof["samples"])
            self.max_samples = int(prof["max_samples"])
            self.pot_samples = int(prof["pot"])
        return self

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d.pop("extra", None)
        return d


def env_flag(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on", "y"}


def load_config_file(path: Optional[str] = None) -> Dict[str, Any]:
    """Optional JSON config; never required for grading."""
    candidates = []
    if path:
        candidates.append(path)
    env_path = os.environ.get("AGENT_CONFIG")
    if env_path:
        candidates.append(env_path)
    default = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")
    candidates.append(default)
    for c in candidates:
        try:
            if c and os.path.isfile(c):
                with open(c, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    return data
        except Exception as exc:  # pragma: no cover - config is optional
            print(f"[config] ignored unreadable config {c}: {exc}", file=sys.stderr)
    return {}


def build_config(args: Optional[Any] = None) -> Config:
    cfg = Config()
    file_cfg = load_config_file(getattr(args, "config", None) if args else None)
    if file_cfg:
        for k, v in file_cfg.items():
            if hasattr(cfg, k) and v is not None:
                setattr(cfg, k, v)

    # environment overrides (useful for CI / grading)
    cfg.model = os.environ.get("OLLAMA_MODEL", cfg.model)
    cfg.host = os.environ.get("OLLAMA_HOST", cfg.host)
    if not cfg.host.startswith("http"):
        cfg.host = "http://" + cfg.host

    if args is not None:
        for attr in ("model", "host", "profile", "samples", "max_samples", "temperature", "num_ctx",
                     "call_timeout", "problem_timeout", "verbose", "log_file", "log_dir", "seed",
                     "top_k"):
            val = getattr(args, attr, None)
            if val is not None:
                setattr(cfg, attr, val)
        if getattr(args, "no_pot", False):
            cfg.use_pot = False
        if getattr(args, "no_cache", False):
            cfg.use_cache = False
        if getattr(args, "think", None) in {"on", "off", "auto"}:
            cfg.think = args.think

    cfg.apply_profile()
    if args is not None and getattr(args, "samples", None) is not None:
        cfg.samples = args.samples
    if cfg.host.endswith("/"):
        cfg.host = cfg.host.rstrip("/")
    return cfg
