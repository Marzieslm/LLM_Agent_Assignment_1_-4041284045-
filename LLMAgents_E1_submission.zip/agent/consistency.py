"""Self-consistency: combine independent answers into one decision.

Sources, from most to least trustworthy:
  * ``exact``    — deterministic solver on the formalised spec (weight 5)
  * ``pot``      — program-of-thought executed and checked (weight 3)
  * ``verify``   — an explicit re-solve / critic pass (weight 2)
  * ``cot``      — one sampled chain-of-thought answer (weight 1)

Voting happens on *canonical* answers, so "۱۵", "15", "15.0" and "**15**" all
count as the same vote.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from .formatting import FormatSpec, canonical

WEIGHTS = {"exact": 5.0, "pot": 3.0, "verify": 2.0, "cot": 1.0}


@dataclass
class Candidate:
    text: str
    source: str
    canonical: Optional[str] = None
    weight: float = 0.0
    detail: str = ""
    ok: bool = True

    def __post_init__(self) -> None:
        if not self.weight:
            self.weight = WEIGHTS.get(self.source, 1.0)


@dataclass
class Decision:
    answer: str = ""
    canonical: Optional[str] = None
    source: str = "none"
    confidence: float = 0.0
    margin: float = 0.0
    ranking: List[Dict[str, object]] = field(default_factory=list)
    reason: str = ""


def make_candidate(text: str, source: str, fmt: FormatSpec, detail: str = "") -> Candidate:
    return Candidate(text=text, source=source, canonical=canonical(text, fmt), detail=detail)


def vote(cands: Sequence[Candidate], restrict_to: Optional[Sequence[str]] = None) -> Decision:
    usable = [c for c in cands if c.ok and c.canonical]
    if restrict_to is not None:
        allowed = {r for r in restrict_to if r}
        restricted = [c for c in usable if c.canonical in allowed]
        if restricted:
            usable = restricted
    if not usable:
        return Decision(source="none", reason="no usable candidates")

    scores: Dict[str, float] = defaultdict(float)
    counts: Dict[str, int] = defaultdict(int)
    best_text: Dict[str, str] = {}
    sources: Dict[str, List[str]] = defaultdict(list)
    for c in usable:
        key = c.canonical
        scores[key] += c.weight
        counts[key] += 1
        sources[key].append(c.source)
        # keep the most "rendered" text for the winner
        if key not in best_text or len(c.text) < len(best_text[key]):
            best_text[key] = c.text

    ranked = sorted(scores.items(), key=lambda kv: (-kv[1], -counts[kv[0]], kv[0]))
    total = sum(scores.values()) or 1.0
    top_key, top_score = ranked[0]
    second = ranked[1][1] if len(ranked) > 1 else 0.0
    decision = Decision(
        answer=best_text.get(top_key, top_key),
        canonical=top_key,
        source=sources[top_key][0] if sources[top_key] else "unknown",
        confidence=top_score / total,
        margin=(top_score - second) / total,
        ranking=[
            {"answer": best_text.get(k, k), "canonical": k, "score": round(v, 2),
             "votes": counts[k], "sources": sources[k]}
            for k, v in ranked[:5]
        ],
    )
    return decision


def agreement(decision: Decision, cands: Sequence[Candidate]) -> bool:
    """True when at least two independent sources back the winning answer."""
    srcs = set()
    for c in cands:
        if c.ok and c.canonical == decision.canonical:
            srcs.add(c.source)
    return len(srcs) >= 2


def low_confidence(decision: Decision, min_share: float = 0.6, min_margin: float = 0.2) -> bool:
    if decision.source == "none":
        return True
    if len(decision.ranking) == 1:
        return False
    return decision.confidence < min_share or decision.margin < min_margin
