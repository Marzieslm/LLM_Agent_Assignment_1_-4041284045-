"""Exact solvers for the reasoning skills used in the exercise.

Every solver is *generic*: it takes a structured description that the language
model extracted from the problem text and computes the answer with an exact
algorithm (linear algebra, exhaustive CSP search, BFS, ...).  No problem text or
answer from the public set is stored here, so the same code applies to unseen
numbers, names and objects.

Why this layer matters: a small local model is unreliable at long arithmetic and
at enumerating combinations, but very good at reading Persian text and mapping it
to structure.  Splitting those two jobs raises accuracy while *lowering* the
number of model calls, which is the tie-breaker in the exercise.
"""
from __future__ import annotations

import itertools
import math
import re
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from .expr import ExprError, evaluate

SKILLS = [
    "linear_algebra",
    "ordering",
    "logic_boxes",
    "schedule",
    "sets",
    "percent_chain",
    "assignment",
    "truth_tellers",
    "grid_path",
    "digit_code",
    "other",
]


@dataclass
class Solved:
    ok: bool
    answers: List[str] = field(default_factory=list)
    unique: bool = False
    detail: str = ""
    query: str = ""
    error: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.ok:
            # de-duplicate while preserving order
            seen, out = set(), []
            for a in self.answers:
                key = a.strip().lower()
                if key not in seen:
                    seen.add(key)
                    out.append(a.strip())
            self.answers = out
            self.unique = len(self.answers) == 1


class SpecError(ValueError):
    pass


def _require(data: Dict[str, Any], key: str, types: Tuple[type, ...] = ()) -> Any:
    if not isinstance(data, dict) or key not in data:
        raise SpecError(f"missing field '{key}'")
    val = data[key]
    if types and not isinstance(val, types):
        raise SpecError(f"field '{key}' has wrong type ({type(val).__name__})")
    return val


def _field(data: Dict[str, Any], names: Sequence[str], types: Tuple[type, ...] = (), required: bool = True) -> Any:
    for name in names:
        if isinstance(data, dict) and name in data:
            val = data[name]
            if types and not isinstance(val, types):
                raise SpecError(f"field '{name}' has wrong type ({type(val).__name__})")
            return val
    if required:
        raise SpecError(f"missing field '{names[0]}'")
    return None


def _as_int(value: Any, field_name: str) -> int:
    if isinstance(value, bool):
        raise SpecError(f"'{field_name}' must be an integer")
    if isinstance(value, int):
        return value
    if isinstance(value, float) and abs(value - round(value)) < 1e-9:
        return int(round(value))
    if isinstance(value, str):
        try:
            return int(float(value.strip()))
        except Exception as exc:
            raise SpecError(f"'{field_name}' is not a number: {value!r}") from exc
    raise SpecError(f"'{field_name}' must be an integer")


def _num_str(value: Any) -> str:
    if isinstance(value, Fraction):
        if value.denominator == 1:
            return str(value.numerator)
        f = float(value)
        return f"{f:.6g}"
    if isinstance(value, float):
        if abs(value - round(value)) < 1e-9:
            return str(int(round(value)))
        return f"{value:.6g}"
    return str(value)


_FA_TRANSLIT = str.maketrans({
    "ا": "a", "آ": "a", "ب": "b", "پ": "p", "ت": "t", "ث": "s", "ج": "j", "چ": "ch",
    "ح": "h", "خ": "kh", "د": "d", "ذ": "z", "ر": "r", "ز": "z", "ژ": "zh", "س": "s",
    "ش": "sh", "ص": "s", "ض": "z", "ط": "t", "ظ": "z", "ع": "a", "غ": "gh", "ف": "f",
    "ق": "gh", "ک": "k", "گ": "g", "ل": "l", "م": "m", "ن": "n", "و": "v", "ه": "h",
    "ی": "y", "ئ": "y", "ء": "", "\u200c": "", " ": "",
})


def _latin_key(name: str) -> str:
    """Approximate transliteration used only for name matching between languages."""
    text = str(name).strip().lower()
    if not text:
        return ""
    if re.search(r"[\u0600-\u06FF]", text):
        text = text.translate(_FA_TRANSLIT)
    return re.sub(r"[^a-z0-9]", "", text)


def _alias_map(unknown: Sequence[str], known: Sequence[str]) -> Dict[str, str]:
    """Map story names to output labels (e.g. کاوه -> Kaveh) by transliteration + similarity."""
    from difflib import SequenceMatcher

    mapping: Dict[str, str] = {}
    used = set()
    pending = []
    for name in unknown:
        if name in known:
            mapping[name] = name
            used.add(name)
        else:
            pending.append(name)
    for name in pending:
        key = _latin_key(name)
        best, score = None, 0.0
        for cand in known:
            if cand in used:
                continue
            ckey = _latin_key(cand)
            if not ckey or not key:
                continue
            ratio = SequenceMatcher(None, key, ckey).ratio()
            if ckey.startswith(key) or key.startswith(ckey):
                ratio = max(ratio, 0.85)
            if ratio > score:
                best, score = cand, ratio
        if best is not None and score >= 0.55:
            mapping[name] = best
            used.add(best)
    return mapping


# --------------------------------------------------------------------------- 1. algebra
def solve_linear_algebra(data: Dict[str, Any]) -> Solved:
    variables: List[str] = [str(v) for v in _field(data, ("variables", "people", "names", "entities"),
                                                  (list, tuple))]
    if not variables:
        raise SpecError("no variables")
    equations = _field(data, ("equations", "system", "relations"), (list, tuple))
    if not equations:
        raise SpecError("no equations")
    n = len(variables)
    index = {v: i for i, v in enumerate(variables)}
    # equations may use the story names (Persian) while the answer format uses labels
    referenced: List[str] = []
    for eq in equations:
        if isinstance(eq, dict):
            coeffs = eq.get("coeffs") or eq.get("coefficients") or eq.get("sum")
            if isinstance(coeffs, dict):
                for name in coeffs:
                    if str(name) not in referenced:
                        referenced.append(str(name))
    aliases = _alias_map(referenced, variables)
    rows: List[List[Fraction]] = []
    rhs: List[Fraction] = []
    for eq in equations:
        if not isinstance(eq, dict):
            raise SpecError("equation must be an object")
        coeffs = eq.get("coeffs") or eq.get("coefficients") or eq.get("sum")
        if not isinstance(coeffs, dict):
            raise SpecError("equation missing 'coeffs' object")
        row = [Fraction(0) for _ in range(n)]
        for name, c in coeffs.items():
            name = str(name)
            mapped = aliases.get(name, name)
            if mapped not in index:
                raise SpecError(f"equation uses unknown variable '{name}'")
            row[index[mapped]] += Fraction(c)
        rows.append(row)
        rhs.append(Fraction(eq.get("rhs", eq.get("value", eq.get("total", 0)))))

    # Gaussian elimination (RREF) over the rationals.
    m = len(rows)
    matrix = [rows[i] + [rhs[i]] for i in range(m)]
    pivot_cols: List[int] = []
    r = 0
    for c in range(n):
        piv = None
        for rr in range(r, m):
            if matrix[rr][c] != 0:
                piv = rr
                break
        if piv is None:
            continue
        matrix[r], matrix[piv] = matrix[piv], matrix[r]
        pv = matrix[r][c]
        matrix[r] = [x / pv for x in matrix[r]]
        for rr in range(m):
            if rr != r and matrix[rr][c] != 0:
                factor = matrix[rr][c]
                matrix[rr] = [a - factor * b for a, b in zip(matrix[rr], matrix[r])]
        pivot_cols.append(c)
        r += 1
        if r == m:
            break

    for rr in range(r, m):
        if all(x == 0 for x in matrix[rr][:n]) and matrix[rr][n] != 0:
            raise SpecError("the extracted equations are inconsistent")

    if len(pivot_cols) < n:
        free = [variables[c] for c in range(n) if c not in pivot_cols]
        raise SpecError(f"equations do not determine a unique solution (free: {', '.join(free)})")

    solution: Dict[str, Any] = {}
    for row_i, c in enumerate(pivot_cols):
        solution[variables[c]] = matrix[row_i][n]
    for v in variables:
        if v not in solution:
            raise SpecError("incomplete solution")

    detail = "; ".join(f"{v}={_num_str(solution[v])}" for v in variables)
    value = ", ".join(f"{v}={_num_str(solution[v])}" for v in variables)
    return Solved(ok=True, answers=[value], detail=detail + " (exact linear solve)", extra={"solution": solution})


# --------------------------------------------------------------------------- 2. ordering
_ORDER_ALIASES = {
    "right_before": "immediately_before", "directly_before": "immediately_before",
    "right_after": "immediately_after", "directly_after": "immediately_after",
    "next_to": "adjacent", "adjacent_to": "adjacent", "consecutive": "adjacent",
    "cannot_be_first": "not_first", "not_the_first": "not_first", "not_first_place": "not_first",
    "cannot_be_last": "not_last", "not_the_last": "not_last", "not_last_place": "not_last",
    "at_position": "position", "in_position": "position",
    "earlier": "before", "earlier_than": "before", "later": "after", "later_than": "after",
}


def _ordering_constraints(items: Sequence[str], constraints: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    parsed = []
    for c in constraints:
        if not isinstance(c, dict):
            raise SpecError("constraint must be an object")
        ctype = re.sub(r"[\s\-]+", "_", str(c.get("type") or c.get("op") or "").strip().lower())
        ctype = _ORDER_ALIASES.get(ctype, ctype)
        if ctype in {"before", "after", "immediately_before", "immediately_after", "next_to", "adjacent"}:
            a = str(c.get("a", c.get("item", c.get("first", ""))))
            b = str(c.get("b", c.get("item2", c.get("second", ""))))
            if a not in items or b not in items or a == b:
                raise SpecError(f"bad ordering pair: {a}, {b}")
            parsed.append({"type": ctype, "a": a, "b": b})
        elif ctype in {"first", "last", "not_first", "not_last"}:
            a = str(c.get("item", c.get("a", "")))
            if a not in items:
                raise SpecError(f"unknown item '{a}'")
            parsed.append({"type": ctype, "a": a})
        elif ctype in {"position", "at_position"}:
            a = str(c.get("item", c.get("a", "")))
            pos = _as_int(c.get("position", c.get("pos")), "position") - 1
            if a not in items:
                raise SpecError(f"unknown item '{a}'")
            parsed.append({"type": "position", "a": a, "pos": pos})
        elif ctype in {"gap", "distance"}:
            a = str(c.get("a", ""))
            b = str(c.get("b", ""))
            parsed.append({"type": "distance", "a": a, "b": b, "d": _as_int(c.get("d", c.get("distance")), "distance")})
        else:
            raise SpecError(f"unknown constraint type '{ctype}'")
    return parsed


def _order_ok(order: Sequence[str], constraints: Sequence[Dict[str, Any]]) -> bool:
    pos = {item: i for i, item in enumerate(order)}
    n = len(order)
    for c in constraints:
        t = c["type"]
        if t == "before" and not pos[c["a"]] < pos[c["b"]]:
            return False
        if t == "after" and not pos[c["a"]] > pos[c["b"]]:
            return False
        if t == "immediately_before" and pos[c["b"]] - pos[c["a"]] != 1:
            return False
        if t == "immediately_after" and pos[c["a"]] - pos[c["b"]] != 1:
            return False
        if t in {"adjacent", "next_to"} and abs(pos[c["a"]] - pos[c["b"]]) != 1:
            return False
        if t == "first" and pos[c["a"]] != 0:
            return False
        if t == "last" and pos[c["a"]] != n - 1:
            return False
        if t == "not_first" and pos[c["a"]] == 0:
            return False
        if t == "not_last" and pos[c["a"]] == n - 1:
            return False
        if t == "position" and pos[c["a"]] != c["pos"]:
            return False
        if t == "distance" and abs(pos[c["a"]] - pos[c["b"]]) != c["d"]:
            return False
    return True


def _find_constraint_list(data: Dict[str, Any]) -> Optional[List[Any]]:
    """Find the constraint list even when the model picked an unexpected key."""
    for key in ("constraints", "rules", "conditions", "restrictions", "clues", "given",
                "facts", "requirements", "condition_list", "constraints_list", "csp"):
        if isinstance(data.get(key), (list, tuple)) and data[key]:
            return list(data[key])
    for value in data.values():
        if isinstance(value, (list, tuple)) and value and all(isinstance(x, dict) for x in value):
            if any(("type" in x or "a" in x or "item" in x or "person" in x) for x in value):
                return list(value)
    return None


def solve_ordering(data: Dict[str, Any]) -> Solved:
    raw_items = _field(data, ("items", "tasks", "letters", "jobs", "elements", "order",
                              "activities", "people", "names"), (list, tuple), required=False)
    items: List[str] = []
    if raw_items is not None:
        for it in raw_items:
            if isinstance(it, dict):
                name = it.get("name") or it.get("item") or it.get("id") or it.get("label")
                if name is None:
                    raise SpecError("item object without a name")
                items.append(str(name))
            else:
                items.append(str(it))
    constraints_raw = _find_constraint_list(data)
    if constraints_raw is None:
        raise SpecError("missing field 'constraints'")
    if not items:
        # derive the item universe from the constraints themselves
        for c in constraints_raw:
            if not isinstance(c, dict):
                continue
            for key in ("a", "b", "item", "first", "second", "item2"):
                val = c.get(key)
                if isinstance(val, str) and val and val not in items:
                    items.append(val)
    if not items:
        raise SpecError("no items")
    if len(items) > 9:
        raise SpecError("too many items to enumerate")
    constraints = _ordering_constraints(items, constraints_raw)
    query = data.get("query") or {"type": "item_at_position", "position": 1}
    if isinstance(query, str):
        query = {"type": query}
    qtype = str(query.get("type") or "item_at_position").lower()

    solutions = [list(p) for p in itertools.permutations(items) if _order_ok(p, constraints)]
    if not solutions:
        raise SpecError("no ordering satisfies the constraints")
    answers: List[str] = []
    if qtype in {"item_at_position", "position_item", "item_at", "which_item", "item_at_first"}:
        qpos = _as_int(query.get("position", query.get("pos", 1)), "position") - 1
        if not 0 <= qpos < len(items):
            raise SpecError("query position out of range")
        answers = [sol[qpos] for sol in solutions]
    elif qtype in {"position_of_item"}:
        qitem = str(query.get("item", ""))
        if qitem not in items:
            raise SpecError(f"unknown query item '{qitem}'")
        answers = [str(sol.index(qitem) + 1) for sol in solutions]
    elif qtype in {"position", "at_position"}:
        if query.get("item"):
            qitem = str(query["item"])
            if qitem not in items:
                raise SpecError(f"unknown query item '{qitem}'")
            answers = [str(sol.index(qitem) + 1) for sol in solutions]
        else:
            qpos = _as_int(query.get("position", query.get("pos", 1)), "position") - 1
            if not 0 <= qpos < len(items):
                raise SpecError("query position out of range")
            answers = [sol[qpos] for sol in solutions]
    elif qtype in {"first"}:
        answers = [sol[0] for sol in solutions]
    elif qtype in {"last"}:
        answers = [sol[-1] for sol in solutions]
    elif qtype in {"order", "full_order", "sequence"}:
        answers = [" ".join(sol) for sol in solutions]
    else:
        raise SpecError(f"unsupported ordering query '{qtype}'")

    detail = f"{len(solutions)} valid ordering(s): " + " | ".join(" ".join(s) for s in solutions[:12])
    if len(solutions) > 12:
        detail += " ..."
    return Solved(ok=True, answers=answers, detail=detail, query=qtype, unique=len(set(answers)) == 1,
                  extra={"solutions": [" ".join(s) for s in solutions]})


# --------------------------------------------------------------------------- 3. logic boxes
def solve_logic_boxes(data: Dict[str, Any]) -> Solved:
    containers = data.get("containers")
    if isinstance(containers, (list, tuple)) and containers:
        n = len(containers)
        labels = [str(c) for c in containers]
    else:
        n = _as_int(data.get("n", data.get("num_boxes", 3)), "n")
        labels = [str(i + 1) for i in range(n)]
    statements = _require(data, "statements", (list, tuple))
    if not statements:
        raise SpecError("no statements")
    exactly_true = _as_int(data.get("exactly_true", 1), "exactly_true")
    exprs = []
    for s in statements:
        if isinstance(s, str):
            exprs.append(s)
        elif isinstance(s, dict):
            e = s.get("expr") or s.get("expression") or s.get("statement")
            if not isinstance(e, str) or not e.strip():
                raise SpecError("statement missing expression")
            exprs.append(e)
        else:
            raise SpecError("statement must be a string or object")

    valid: List[str] = []
    for pos in range(1, n + 1):
        truth_count = 0
        for expr in exprs:
            env = {"pos": pos, "box": pos, "n": n}
            try:
                if evaluate(expr, env):
                    truth_count += 1
            except ExprError as exc:
                raise SpecError(f"bad statement '{expr}': {exc}") from exc
        if truth_count == exactly_true:
            valid.append(labels[pos - 1])
    if not valid:
        raise SpecError("no container satisfies the truth conditions")
    return Solved(ok=True, answers=valid, detail=f"valid containers: {', '.join(valid)}", query="container")


# --------------------------------------------------------------------------- 4. schedule
def solve_schedule(data: Dict[str, Any]) -> Solved:
    activities = _require(data, "activities", (list, tuple))
    if not activities:
        raise SpecError("no activities")
    durations: Dict[str, int] = {}
    deps: Dict[str, List[str]] = {}
    order_in: List[str] = []
    for a in activities:
        if not isinstance(a, dict):
            raise SpecError("activity must be an object")
        name = str(a.get("name") or a.get("activity") or "").strip()
        if not name:
            raise SpecError("activity missing name")
        dur = _as_int(a.get("duration", a.get("days", a.get("time", 0))), f"duration of {name}")
        if dur < 0:
            raise SpecError("negative duration")
        durations[name] = dur
        dep = a.get("deps") or a.get("dependencies") or a.get("predecessors") or []
        deps[name] = [str(d) for d in dep]
        order_in.append(name)
    for name, ds in deps.items():
        for d in ds:
            if d not in durations:
                raise SpecError(f"unknown dependency '{d}' for '{name}'")

    # longest path in a DAG (finish-to-start)
    finish: Dict[str, int] = {}
    visiting: set = set()

    def computed(name: str) -> int:
        if name in finish:
            return finish[name]
        if name in visiting:
            raise SpecError("dependency cycle detected")
        visiting.add(name)
        start_t = max([computed(d) for d in deps[name]], default=0)
        finish[name] = start_t + durations[name]
        visiting.discard(name)
        return finish[name]

    for name in order_in:
        computed(name)
    makespan = max(finish.values())
    query = str(data.get("query") or "makespan").lower()
    if query in {"makespan", "project", "finish", "total", "duration"}:
        answers = [str(makespan)]
        detail = "earliest starts: " + ", ".join(
            f"{n}@{finish[n] - durations[n]}" for n in order_in
        ) + f"; makespan={makespan}"
    elif query.startswith("finish:"):
        target = query.split(":", 1)[1]
        if target not in finish:
            raise SpecError(f"unknown activity '{target}'")
        answers, detail = [str(finish[target])], f"finish({target})={finish[target]}"
    elif query.startswith("start:"):
        target = query.split(":", 1)[1]
        if target not in finish:
            raise SpecError(f"unknown activity '{target}'")
        answers, detail = [str(finish[target] - durations[target])], f"start({target})={finish[target] - durations[target]}"
    else:
        answers, detail = [str(makespan)], f"makespan={makespan}"
    return Solved(ok=True, answers=answers, detail=detail, query=query, extra={"finish": finish})


# --------------------------------------------------------------------------- 5. sets
def solve_sets(data: Dict[str, Any]) -> Solved:
    total = _as_int(data.get("total", data.get("students", data.get("class_size", data.get("n")))), "total")
    sets_spec = _require(data, "sets", (list, tuple, dict))
    sizes: Dict[str, int] = {}
    if isinstance(sets_spec, dict):
        for name, size in sets_spec.items():
            sizes[str(name)] = _as_int(size, f"size of {name}")
    else:
        for s in sets_spec:
            if isinstance(s, dict):
                name = str(s.get("name") or s.get("set") or "")
                size = _as_int(s.get("size", s.get("count", 0)), f"size of {name}")
            elif isinstance(s, (list, tuple)) and len(s) == 2:
                name, size = str(s[0]), _as_int(s[1], "size")
            else:
                raise SpecError("set entry must be an object with name/size")
            if not name:
                raise SpecError("set missing name")
            sizes[name] = size
    names = list(sizes)

    inter: Dict[frozenset, int] = {}
    raw_inter = (data.get("intersections") or data.get("overlaps") or data.get("both")
                 or data.get("intersection") or [])
    if isinstance(raw_inter, (int, float)) and len(names) == 2:
        inter[frozenset(names)] = _as_int(raw_inter, "intersection")
    elif isinstance(raw_inter, dict):
        for key, val in raw_inter.items():
            members = [m.strip() for m in str(key).replace("∩", ",").replace("&", ",").split(",") if m.strip()]
            members = [m for m in members if m in sizes]
            if len(members) >= 2:
                inter[frozenset(members)] = _as_int(val, f"intersection {key}")
    elif isinstance(raw_inter, (list, tuple)):
        for item in raw_inter:
            if not isinstance(item, dict):
                continue
            members = [str(m) for m in (item.get("members") or item.get("sets") or [])]
            members = [m for m in members if m in sizes]
            if len(members) >= 2:
                inter[frozenset(members)] = _as_int(item.get("size", item.get("count", 0)), "intersection")

    # Inclusion-exclusion over all non-empty subsets that we have data for.
    union = 0
    missing_full = False
    for r in range(1, len(names) + 1):
        for combo in itertools.combinations(names, r):
            key = frozenset(combo)
            if r == 1:
                val = sizes[combo[0]]
            elif key in inter:
                val = inter[key]
            else:
                if r == len(names):
                    missing_full = True
                val = 0
            union += ((-1) ** (r + 1)) * val
    if missing_full and len(names) > 2:
        raise SpecError("missing the intersection of all sets")
    query = str(data.get("query") or "neither").lower()
    if query in {"neither", "none", "outside"}:
        answer = total - union
        detail = f"union={union}; neither={answer}"
    elif query in {"union", "at_least_one"}:
        answer = union
        detail = f"union={union}"
    elif query in {"both", "intersection"} and len(names) == 2:
        answer = inter.get(frozenset(names), 0)
        detail = f"intersection={answer}"
    else:
        answer = total - union
        detail = f"union={union}; neither={answer}"
    if answer < 0:
        raise SpecError("extracted set sizes are inconsistent (negative result)")
    return Solved(ok=True, answers=[str(answer)], detail=detail, query=query)


# --------------------------------------------------------------------------- 6. percentage
def solve_percent_chain(data: Dict[str, Any]) -> Solved:
    ops = _require(data, "ops", (list, tuple))
    factor = Fraction(1)
    for op in ops:
        if not isinstance(op, dict):
            raise SpecError("operation must be an object")
        kind = str(op.get("type") or op.get("op") or "").lower()
        pct = Fraction(str(op.get("pct", op.get("percent", op.get("value", 0)))))
        if kind in {"increase", "raise", "up", "markup"}:
            factor *= 1 + pct / 100
        elif kind in {"decrease", "discount", "down", "reduction"}:
            factor *= 1 - pct / 100
        else:
            raise SpecError(f"unknown percentage operation '{kind}'")
    if factor == 0:
        raise SpecError("multiplier is zero")
    final = data.get("final", data.get("final_price"))
    initial = data.get("initial", data.get("initial_price"))
    query = str(data.get("query") or ("initial" if initial is None else "final")).lower()
    if query in {"initial", "original", "start"}:
        if final is None:
            raise SpecError("final value missing")
        answer = Fraction(str(final)) / factor
        detail = f"multiplier={factor}; initial={_num_str(answer)}"
    else:
        if initial is None:
            raise SpecError("initial value missing")
        answer = Fraction(str(initial)) * factor
        detail = f"multiplier={factor}; final={_num_str(answer)}"
    return Solved(ok=True, answers=[_num_str(answer)], detail=detail, query=query)


# --------------------------------------------------------------------------- 7. assignment
_ASSIGN_CONSTRAINTS = {
    "equal", "equals", "is", "same", "not_equal", "not_equals", "different", "not_same",
    "before", "earlier", "after", "later", "immediately_before", "immediately_after",
    "one_day_before", "one_day_after", "next_day", "previous_day", "position", "at",
}


def _assign_ok(assignment: Dict[str, str], slots: Sequence[str], constraints: Sequence[Dict[str, Any]]) -> bool:
    idx = {s: i for i, s in enumerate(slots)}
    for c in constraints:
        t = str(c.get("type") or "").lower()
        p = str(c.get("person", c.get("a", "")))
        if t in {"equal", "equals", "is", "same"}:
            slot = str(c.get("slot", c.get("value", "")))
            if assignment.get(p) != slot:
                return False
        elif t in {"not_equal", "not_equals", "different", "not_same"}:
            slot = str(c.get("slot", c.get("value", "")))
            if assignment.get(p) == slot:
                return False
        elif t in {"position", "at"}:
            slot = str(c.get("slot", c.get("value", "")))
            if assignment.get(p) != slot:
                return False
        elif t in {"before", "earlier", "after", "later", "immediately_before", "immediately_after",
                   "one_day_before", "one_day_after", "next_day", "previous_day"}:
            q = str(c.get("b", c.get("person2", c.get("other", ""))))
            if p not in assignment or q not in assignment:
                return False
            ip, iq = idx[assignment[p]], idx[assignment[q]]
            if t in {"before", "earlier"} and not ip < iq:
                return False
            if t in {"after", "later"} and not ip > iq:
                return False
            if t in {"immediately_before", "one_day_before", "previous_day"} and iq - ip != 1:
                return False
            if t in {"immediately_after", "one_day_after", "next_day"} and ip - iq != 1:
                return False
        else:
            raise SpecError(f"unknown assignment constraint '{t}'")
    return True


def solve_assignment(data: Dict[str, Any]) -> Solved:
    people = [str(p) for p in _require(data, "people", (list, tuple))]
    slots = [str(s) for s in _require(data, "slots", (list, tuple))]
    constraints = _require(data, "constraints", (list, tuple))
    if not people or not slots:
        raise SpecError("people/slots missing")
    if len(people) > len(slots):
        raise SpecError("more people than slots")
    if math.perm(len(slots), len(people)) > 400_000:
        raise SpecError("assignment search space too large")
    query = data.get("query") or {"type": "slot_of", "person": people[0]}
    if isinstance(query, str):
        query = {"type": query, "person": people[0]}

    answers: List[str] = []
    count = 0
    sample = []
    for combo in itertools.permutations(slots, len(people)):
        assignment = dict(zip(people, combo))
        if _assign_ok(assignment, slots, constraints):
            count += 1
            if len(sample) < 12:
                sample.append("; ".join(f"{p}={assignment[p]}" for p in people))
            qtype = str(query.get("type") or "slot_of").lower()
            if qtype in {"slot_of", "day_of", "when"}:
                person = str(query.get("person", people[0]))
                if person not in assignment:
                    raise SpecError(f"unknown person '{person}'")
                answers.append(assignment[person])
            elif qtype in {"person_at", "who_at", "at_slot"}:
                slot = str(query.get("slot", query.get("day", slots[0])))
                inv = {v: k for k, v in assignment.items()}
                if slot not in inv:
                    continue
                answers.append(inv[slot])
            else:
                answers.append("; ".join(f"{p}={assignment[p]}" for p in people))
    if count == 0:
        raise SpecError("no assignment satisfies the constraints")
    if not answers:
        raise SpecError("query could not be answered from the valid assignments")
    detail = f"{count} valid assignment(s); e.g. " + " | ".join(sample)
    return Solved(ok=True, answers=answers, detail=detail, unique=len(set(answers)) == 1,
                  extra={"count": count, "sample": sample})


# --------------------------------------------------------------------------- 8. truth tellers
_TRUTH_PATTERNS_SAME = [
    r"من و (\S+) از یک نوع",
    r"(\S+) و من از یک نوع",
    r"(?:i and|me and) (\w+) are (?:of )?the same type",
    r"(\w+) and i are (?:of )?the same type",
]
_TRUTH_PATTERNS_DIFF = [
    r"من و (\S+) از دو نوع متفاوت",
    r"(\S+) و من از دو نوع متفاوت",
    r"(?:i and|me and) (\w+) are (?:of )?different types",
    r"(\w+) and i are (?:of )?different types",
]


def _translate_truth_statement(speaker: str, text: str, names: Sequence[str]) -> str:
    """Compile common natural-language statements into boolean expressions.

    The formaliser is instructed to emit expressions, but small models sometimes write
    ``"Bita is a liar"`` or ``"من و علی از دو نوع متفاوت هستیم"``.  Handling those here
    keeps the exact solver usable instead of discarding a correct model reading.
    """
    raw = (text or "").strip().rstrip(".!؟?؛;،,")
    if not raw:
        raise SpecError("empty statement")
    # Already a boolean expression over the people?
    for probe in (raw, raw.replace("Truth", "True").replace("Lie", "False")):
        try:
            evaluate(probe, {**{n: True for n in names}, "Truth": True, "Lie": False})
            return probe
        except Exception:
            pass
    low = raw.lower()
    others = [n for n in names if n != speaker]

    def resolve(other: str) -> str:
        if other in names:
            return other
        # a single counterpart in the puzzle: the text may use another script
        return others[0] if len(others) == 1 else other

    for pat in _TRUTH_PATTERNS_SAME:
        m = re.search(pat, raw, flags=re.I)
        if m:
            return f"{speaker} == {resolve(m.group(1))}"
    for pat in _TRUTH_PATTERNS_DIFF:
        m = re.search(pat, raw, flags=re.I)
        if m:
            return f"{speaker} != {resolve(m.group(1))}"
    for other in names:
        if other == speaker:
            continue
        o = re.escape(other)
        if re.search(rf"{o}\s+(?:دروغگو|دروغگوی|دروغ\s*می\s*گوید)", raw) or re.search(
            rf"\b{o}\b\s+(?:is\s+)?(?:a\s+)?(?:liar|lying|dishonest)\b", raw, flags=re.I
        ):
            return f"not {other}"
        if re.search(rf"{o}\s+(?:راستگو|راستگوی|راست\s*می\s*گوید)", raw) or re.search(
            rf"\b{o}\b\s+(?:is\s+)?(?:truthful|honest|a\s+truth-?teller)\b", raw, flags=re.I
        ):
            return f"{other}"
    if re.search(r"من.*(?:دروغگو|دروغ)", raw):
        return "not " + speaker
    if re.search(r"من.*(?:راستگو|راست)", raw):
        return speaker if speaker in names else "True"
    raise SpecError(f"cannot compile statement: {text!r}")


def solve_truth_tellers(data: Dict[str, Any]) -> Solved:
    people = _require(data, "people", (list, tuple))
    names: List[str] = []
    raw_statements: Dict[str, str] = {}
    for p in people:
        if not isinstance(p, dict):
            raise SpecError("person must be an object")
        name = str(p.get("name") or "")
        stmt = p.get("statement") or p.get("says")
        if not name or not isinstance(stmt, str):
            raise SpecError("person needs name and statement")
        names.append(name)
        raw_statements[name] = stmt
    statements = {name: _translate_truth_statement(name, raw_statements[name], names) for name in names}
    n = len(names)
    if n > 12:
        raise SpecError("too many people")
    models: List[Dict[str, bool]] = []
    for bits in itertools.product([False, True], repeat=n):
        env = dict(zip(names, bits))
        env["Truth"], env["Lie"] = True, False
        ok = True
        for name in names:
            try:
                stmt_true = bool(evaluate(statements[name], env))
            except ExprError as exc:
                raise SpecError(f"bad statement for {name}: {exc}") from exc
            if stmt_true != env[name]:
                ok = False
                break
        if ok:
            models.append({k: v for k, v in env.items() if k in names})
    if not models:
        raise SpecError("no consistent truth assignment")

    def render(env: Dict[str, bool]) -> str:
        truths = [n_ for n_ in names if env[n_]]
        lies = [n_ for n_ in names if not env[n_]]
        parts = [f"Truth={x}" for x in truths] + [f"Lie={x}" for x in lies]
        return ", ".join(parts)

    query = data.get("query")
    if isinstance(query, dict):
        qtype = str(query.get("type") or "types").lower()
    else:
        qtype = str(query or "types").lower()
    if qtype in {"types", "status", "who", "all"}:
        answers = [render(m) for m in models]
    elif qtype in {"who_lies", "liars"}:
        answers = [", ".join(x for x in names if not m[x]) for m in models]
    elif qtype in {"who_truths", "truthful"}:
        answers = [", ".join(x for x in names if m[x]) for m in models]
    elif qtype.startswith("status_of:"):
        person = qtype.split(":", 1)[1]
        if person not in names:
            raise SpecError(f"unknown person '{person}'")
        answers = ["Truth" if m[person] else "Lie" for m in models]
    else:
        answers = [render(m) for m in models]
    detail = f"{len(models)} consistent model(s): " + " | ".join(render(m) for m in models)
    return Solved(ok=True, answers=answers, detail=detail, unique=len(set(answers)) == 1)


# --------------------------------------------------------------------------- 9. grid path
def solve_grid_path(data: Dict[str, Any]) -> Solved:
    def pair(obj: Any, name: str) -> Tuple[int, int]:
        if isinstance(obj, dict):
            x = _as_int(obj.get("x"), f"{name}.x")
            y = _as_int(obj.get("y"), f"{name}.y")
            return x, y
        if isinstance(obj, (list, tuple)) and len(obj) == 2:
            return _as_int(obj[0], f"{name}[0]"), _as_int(obj[1], f"{name}[1]")
        raise SpecError(f"bad point '{name}'")

    start = pair(_require(data, "start"), "start")
    goal_raw = data.get("goal") if "goal" in data else data.get("target")
    if goal_raw is None:
        raise SpecError("missing field 'goal'")
    goal = pair(goal_raw, "goal")
    blocked_raw = data.get("blocked") or data.get("obstacles") or []
    blocked = {pair(b, "blocked") for b in blocked_raw}
    bounds = data.get("bounds") or {}
    if isinstance(bounds, dict) and ("x" in bounds or "y" in bounds):
        xr = bounds.get("x") or [0, 0]
        yr = bounds.get("y") or [0, 0]
        xmin, xmax = _as_int(xr[0], "xmin"), _as_int(xr[1], "xmax")
        ymin, ymax = _as_int(yr[0], "ymin"), _as_int(yr[1], "ymax")
    else:
        xmin, ymin = _as_int(bounds.get("xmin", 0), "xmin"), _as_int(bounds.get("ymin", 0), "ymin")
        xmax, ymax = _as_int(bounds.get("xmax", max(start[0], goal[0])), "xmax"), _as_int(
            bounds.get("ymax", max(start[1], goal[1])), "ymax"
        )
    if not (xmin <= start[0] <= xmax and ymin <= start[1] <= ymax):
        raise SpecError("start outside bounds")
    if not (xmin <= goal[0] <= xmax and ymin <= goal[1] <= ymax):
        raise SpecError("goal outside bounds")
    if start == goal:
        return Solved(ok=True, answers=["0"], detail="start == goal", query="moves")

    from collections import deque

    dist = {start: 0}
    q = deque([start])
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if not (xmin <= nx <= xmax and ymin <= ny <= ymax):
                continue
            if (nx, ny) in blocked or (nx, ny) in dist:
                continue
            dist[(nx, ny)] = dist[(x, y)] + 1
            if (nx, ny) == goal:
                q.clear()
                break
            q.append((nx, ny))
    if goal not in dist:
        raise SpecError("goal unreachable")
    return Solved(ok=True, answers=[str(dist[goal])], detail=f"shortest path = {dist[goal]} moves", query="moves")


# --------------------------------------------------------------------------- 10. digit code
_OP_SYMBOLS = {
    "greater_than": ">", "gt": ">", "more_than": ">", ">": ">",
    "less_than": "<", "lt": "<", "smaller_than": "<", "<": "<",
    "greater_or_equal": ">=", "at_least": ">=", ">=": ">=",
    "less_or_equal": "<=", "at_most": "<=", "<=": "<=",
    "equals": "==", "equal": "==", "eq": "==", "==": "==",
    "not_equals": "!=", "neq": "!=", "different": "!=", "!=": "!=",
}


def _digit_constraint_expr(c: Any) -> str:
    """Accept either an expression string or a small structured constraint object."""
    if isinstance(c, str):
        return c
    if isinstance(c, dict):
        t = str(c.get("type") or c.get("op") or "").strip().lower()
        a = c.get("a", c.get("left", c.get("lhs")))
        b = c.get("b", c.get("right", c.get("rhs")))
        if t in _OP_SYMBOLS and a is not None and b is not None:
            return f"{a} {_OP_SYMBOLS[t]} {b}"
        if t in {"in", "not_in", "notin"} and a is not None:
            vals = b if b is not None else c.get("values", [])
            op = "in" if t == "in" else "not in"
            return f"{a} {op} {vals}"
        if t in {"sum_equals", "sum_is"}:
            parts = a if isinstance(a, (list, tuple)) else [a]
            return " + ".join(str(x) for x in parts) + f" == {b}"
        if t in {"digit_not_used", "not_used", "excluded"}:
            digit = c.get("digit", a)
            return f"{digit} not in [d1, d2, d3, d4, d5, d6]"
        if t in {"distinct", "all_different"}:
            return "True"
    raise SpecError(f"unrecognised digit constraint: {c!r}")


def solve_digit_code(data: Dict[str, Any]) -> Solved:
    length = _as_int(data.get("length", 3), "length")
    pool = [_as_int(x, "pool") for x in _require(data, "pool", (list, tuple))]
    distinct = bool(data.get("distinct", True))
    constraints = data.get("constraints") or []
    if not isinstance(constraints, (list, tuple)):
        raise SpecError("constraints must be a list")
    if length < 1 or length > 6:
        raise SpecError("unsupported code length")
    if length > len(pool):
        raise SpecError("pool smaller than code length")

    candidates = itertools.permutations(pool, length) if distinct else itertools.product(pool, length)
    expressions = [_digit_constraint_expr(c) for c in constraints]
    answers: List[str] = []
    count = 0
    for digits in candidates:
        env = {f"d{i + 1}": digits[i] for i in range(length)}
        env["digits"] = list(digits)
        ok = True
        for expr in expressions:
            if expr == "True":
                continue
            try:
                if not evaluate(expr, env):
                    ok = False
                    break
            except ExprError as exc:
                raise SpecError(f"bad constraint '{expr}': {exc}") from exc
        if ok:
            count += 1
            answers.append("".join(str(d) for d in digits))
    if count == 0:
        raise SpecError("no code satisfies the constraints")
    space = math.perm(len(pool), length) if distinct else len(pool) ** length
    return Solved(ok=True, answers=answers, detail=f"{count} valid code(s): {', '.join(answers[:12])}",
                  query="code", extra={"search_space": space})


SOLVERS = {
    "linear_algebra": solve_linear_algebra,
    "ordering": solve_ordering,
    "logic_boxes": solve_logic_boxes,
    "schedule": solve_schedule,
    "sets": solve_sets,
    "percent_chain": solve_percent_chain,
    "assignment": solve_assignment,
    "truth_tellers": solve_truth_tellers,
    "grid_path": solve_grid_path,
    "digit_code": solve_digit_code,
}


def solve(skill: str, data: Dict[str, Any]) -> Solved:
    fn = SOLVERS.get(str(skill).strip().lower())
    if fn is None:
        return Solved(ok=False, error=f"unknown skill '{skill}'")
    try:
        return fn(data)
    except SpecError as exc:
        return Solved(ok=False, error=str(exc))
    except Exception as exc:  # noqa: BLE001 - solver bugs must not kill the run
        return Solved(ok=False, error=f"solver crashed: {type(exc).__name__}: {exc}")
